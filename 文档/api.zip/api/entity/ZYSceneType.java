package com.zyiot.sdk.entity;

/***
 * 场景的任务类型：定时任务、设备联动
 * @author cxm
 */
public enum ZYSceneType {
     None((byte) 100),//未知类型
    TimerTask((byte) 0),//0-定时任务
    DevLinkageTask((byte) 1);//1-联动任务

    private byte type;

    private ZYSceneType(byte type) {
        this.type = type;
    }

    public byte getType() {
        return type;
    }

    @Override
    public String toString() {
        return Byte.toString(type);
    }
}
