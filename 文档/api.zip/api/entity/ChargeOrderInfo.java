package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 购买套餐时返回下单的数据封装如下：（用于调起微信支付时使用）
 */
public class ChargeOrderInfo implements Serializable {
	private String  returnCode;// SUCCESS
	private String appid;//wx7fc65f8b50266ad2
	private String mchId;//":"1363585302
	private String nonceStr;//":"DfP2DxCJNb8wGsMlXom7Fw3bKbscaGlT
	private String resultCode;//":"SUCCESS
	private String tradeType;//":"APP
	private String prepayId;//":"wx20170622115755a12f57ae7d1384490176
	private long timestamp;//second":1498103878," +
	private String sign;//":"9A3884CBB97C10F478F706DE4DF87995"

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getNonceStr() {
		return nonceStr;
	}

	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getPrepayId() {
		return prepayId;
	}

	public void setPrepayId(String prepayId) {
		this.prepayId = prepayId;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	@Override
	public String toString() {
		return "ChargeOrderInfo [returnCode="
				+ returnCode + ", appid=" + appid + ", mchId="
				+ mchId + ", nonceStr=" + nonceStr + ", resultCode=" + resultCode+",prepayId="+prepayId+",sign="+sign
				+",t="+timestamp+ "]";
	}

}
