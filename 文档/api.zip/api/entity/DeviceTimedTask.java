package com.zyiot.sdk.entity;

/**定时任务时间有两种，一种是定期单次任务，一种是周重复任务。
* 定期单次任务是指定具体时间，为年月日时分的时间戳，周重复任务是指定周几的几时几分。最小精确到分钟。设备管理员才可以为设备设置定时。*/
public class DeviceTimedTask implements java.io.Serializable{

    /**定时任务标识ID，创建定时任务后可得*/
    private String timedTaskId;

    /**任务触发时间，如果是定期单次（时间戳单位：秒），如北京时间2017/11/7 10:26:00，存储为1510021560。如果是周重复任务，time为小时分钟转换成秒数，小时分钟随系统时间。*/
    private String time;

    /**任务重复，如果是定期单次任务，repeat为空。如果是周重复任务（分隔符是英文分号），repeat才有效。repeat值为1,2,3,4,5,6,7，分别代表周一到周日,多天时需要用英文符逗号分隔开。如值为1,3,6表示周一周三周六。*/
    private String repeat;

    /**指定执行的设备*/
    private String keyhash;

    /**属性名，指定执行的动作名*/
    private String attrName;

    /**属性值，指定执行的动作*/
    private String attrValue;

    /**备注*/
    private String remark;

    /**场景标识ID，创建场景后可得。若本任务没有添加到场景中，则本字段为空*/
    private String sceneId;

    public String getTimedTaskId() {
        return timedTaskId;
    }

    public void setTimedTaskId(String timedTaskId) {
        this.timedTaskId = timedTaskId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRepeat() {
        return repeat;
    }

    public void setRepeat(String repeat) {
        this.repeat = repeat;
    }

    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrValue() {
        return attrValue;
    }

    public void setAttrValue(String attrValue) {
        this.attrValue = attrValue;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    @Override
    public String toString() {
        return "TimedTask[id=" + timedTaskId + ",dev1=" + keyhash + ",attr="+attrName+",attrV="+attrValue+",t="+time+",weekRepeats="+repeat+",remark="+remark+",sceneId="+sceneId+ "]";
    }
}