package com.zyiot.sdk.entity;

import com.zyiot.sdk.utils.StrParseToNum;

import java.io.Serializable;
import java.util.List;

/**  设备场景，可为场景添加定时任务或联动任务
 * @author cxm
 */
@SuppressWarnings("serial")
public class DeviceSceneInfo implements Serializable {

    /**场景ID，标识场景  */
    private String sceneId;

    /**场景名称  */
    private String name;

    /**场景内的任务类型：1是设备联动；0是定时任务 */
    private int type;

    /**创建场景的时间，时间戳单位：秒  */
    private long timestamp;

    /** 场景备注  */
    private String remark;

    /**场景图片地址（暂不支持）  */
    private String imagPath;

    /** 场景内的联动任务。当场景类型是1联动任务时，此值有效  */
    private List<DeviceLinkage> linkages;

    /** 场景内的定时任务。 当场景类型是0定时任务时，此值有效  */
    private List<DeviceTimedTask> timedTasks;




    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(String type) {
        this.type = StrParseToNum.parseToInt(type, 0);
    }

    public void setType(int type) {
        this.type = type;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getImagPath() {
        return imagPath;
    }

    public void setImagPath(String imagPath) {
        this.imagPath = imagPath;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public List<DeviceLinkage> getLinkages() {
        return linkages;
    }

    public void setLinkages(List<DeviceLinkage> linkages) {
        this.linkages = linkages;
    }

    public List<DeviceTimedTask> getTimedTasks() {
        return timedTasks;
    }

    public void setTimedTasks(List<DeviceTimedTask> timedTasks) {
        this.timedTasks = timedTasks;
    }

    @Override
    public String toString() {
        return sceneId+",type="+type+",name="+name+",t="+timestamp+",remark="+remark+","+timedTasks+":"+linkages;
    }

}
