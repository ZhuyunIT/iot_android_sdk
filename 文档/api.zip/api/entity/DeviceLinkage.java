package com.zyiot.sdk.entity;

/**
 * 设备联动，可以是同一个设备的不同属性值联动，也可以是同一个用户下的不同设备进行联动。
 * 若设备操控时间过期，设备联动将不能成功。设备联动执行时没有返回结果，如果有设置推送，则有推送通知。
 * 时间戳单位：秒
 */
public class DeviceLinkage implements java.io.Serializable {

    /**
     * 联动任务标识ID，创建联动任务后可得
     */
    private String linkageId;

    /**
     * 时间限制，json格式数据： type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。
     * 形如：{"type":"2","time":"12345-23456","week":"127"}
     */
    private String timelimit;

    /**
     * 指定触发的设备
     */
    private String keyhash;

    /**
     * 属性名，指定触发的动作名
     */
    private String attrName;

    /**
     * 触发条件——属性值条件判断。json格式数据，包含operation，threshold。operation：触发条件，包括：>，<，>=，<=，==，!=，contains，equals。threshold：阈值。
     * 形如：{"operation":">","threshold":"20"}
     */
    private String condition;

    /**
     * 触发后执行的设备
     */
    private String keyhash2;

    /**
     * 属性名，触发后执行的动作名
     */
    private String attrName2;

    /**
     * 属性值，触发后执行的动作
     */
    private String attrValue2;

    /**
     * 备注
     */
    private String remark;

    /**
     * 场景标识ID，创建场景后可得。若本任务没有添加到场景中，则本字段为空
     */
    private String sceneId;

    public String getLinkageId() {
        return linkageId;
    }

    public void setLinkageId(String linkageId) {
        this.linkageId = linkageId;
    }

    public String getTimelimit() {
        return timelimit;
    }

    public void setTimelimit(String timelimit) {
        this.timelimit = timelimit;
    }

    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getKeyhash2() {
        return keyhash2;
    }

    public void setKeyhash2(String keyhash2) {
        this.keyhash2 = keyhash2;
    }

    public String getAttrName2() {
        return attrName2;
    }

    public void setAttrName2(String attrName2) {
        this.attrName2 = attrName2;
    }

    public String getAttrValue2() {
        return attrValue2;
    }

    public void setAttrValue2(String attrValue2) {
        this.attrValue2 = attrValue2;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSceneId() {
        return sceneId;
    }

    public void setSceneId(String sceneId) {
        this.sceneId = sceneId;
    }

    @Override
    public String toString() {
        return "DevLinkage[id=" + linkageId + ",dev1=" + keyhash + ",dev2=" + keyhash2 +",attr1="+attrName+",v1ConJson="+condition+",attr2="+attrName2+",v2="+attrValue2+",tJson="+timelimit+",remark="+remark+",sceneId="+sceneId+ "]";
    }
}