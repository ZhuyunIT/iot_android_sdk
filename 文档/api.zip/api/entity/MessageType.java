package com.zyiot.sdk.entity;

/***
 * 筑云消息中心的消息类型
 * @author cxm
 *
 */
public class MessageType {

	/**消息类型Id*/
	private int id;

	/**消息类型名称*/
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	@Override
	public String toString() {
		return  id+"="+name;
	}
}
