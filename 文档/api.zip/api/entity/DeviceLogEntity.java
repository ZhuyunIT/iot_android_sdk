package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 设备历史记录，历史记录的类型：1指设备异常-如设备上下线；2指操控记录；3指分享与绑定；4指其它。
 *
 * @author cxm
 */
public class DeviceLogEntity implements Serializable,Comparable<DeviceLogEntity>  {

    /**
     * 设备keyhash
     */
    private String keyhash;

    /**
     * 属性名
     */
    private String attrName;

    /**
     * 属性值
     */
    private String attrValue;

    /**
     * 属性值解析后的文字内容（与APP/微信/邮箱接收到的推送内容一样）
     */
    private String content;

    /**
     * 历史记录的类型，1设备异常-如设备上下线；2操控；3分享与绑定；4其它
     */
    private String type;

    /**
     * 历史记录产生的时间戳(单位：秒)
     */
    private long timestamp;

    /**
     * 如果绑定摄像头，且有抓拍到图片，则本字段表示抓拍的图片路径
     */
    private String capture;

    public DeviceLogEntity() {
        // TODO Auto-generated constructor stub
    }

    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrValue() {
        return attrValue;
    }

    public void setAttrValue(String attrValue) {
        this.attrValue = attrValue;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getCapture() {
        return capture;
    }

    public void setCapture(String capture) {
        this.capture = capture;
    }



    @Override
    public int compareTo(DeviceLogEntity anotherLog) {
        // TODO Auto-generated method stub
        long t1= timestamp ;
        long t2= anotherLog.getTimestamp() ;
        if(t1>t2){
            return 1;
        }
        if(t1==t2){
            if(attrName.equals(anotherLog.getAttrName())&&attrValue.equals(anotherLog.getAttrValue())){
                return 0;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        return "DevLog[attrName=" + attrName + ",content=" + content
               +",attrV=" +attrValue+",t="+timestamp+ "]";
    }

}
