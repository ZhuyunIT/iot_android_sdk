package com.zyiot.sdk.entity;

import android.text.TextUtils;

import com.zyiot.sdk.utils.AboutTime;
import com.zyiot.sdk.utils.StrParseToNum;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**本实体类是对二级用户权限(时段访问权限)的封装—— 1 年月日时间（日期时间区间）
 * @author cxm
 */
public class AuthorityEntity1 extends AuthorityEntity implements Serializable {

	/**timestamp1是起始时间日期，timestamp2终止时间日期
	 * timestamp1-timestamp2是年月日时间点时间戳区间，不可重复
	 * 时间戳单位：秒
	 */
	private long timestamp1;
	private long timestamp2;


	public AuthorityEntity1( ){
		super(1);
	}

	@Override
	public int getValidType() {
		return 1;
	}

	/**权限结束时间：年月日时分的时间戳，单位秒
	 * @return
	 */
	public long getTimestamp1() {
		return timestamp1;
	}

	/**权限开始时间：年月日时分 ，时间戳单位秒
	 * @param timestamp1
	 */
	public void setTimestamp1(long timestamp1) {
		this.timestamp1 = timestamp1;
	}

	public long getTimestamp2() {
		return timestamp2;
	}

	public void setTimestamp2(long timestamp2) {
		this.timestamp2 = timestamp2;
	}

	public String getJsonStrAuthorityDescription() {
		return getAuthorityJSON().toString();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Authority1[type="+getValidType() + ",t1=" + timestamp1 + ",t2=" + timestamp2 +", shareT="+getShareTime()+"]";
	}
}

