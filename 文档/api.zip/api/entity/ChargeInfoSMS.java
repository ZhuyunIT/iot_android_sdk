package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 短信套餐。用户的获取短信验证码次数有限（默认10次），购买短信套餐可以增加获取短信验证码次数。
 * @author cxm
 *
 */
public class ChargeInfoSMS implements Serializable{

	/**套餐id*/
	private String chargeId;
	/**套餐价格，单位：分 */
	private int price;
	/***短信数（获取验证码次数）*/
	private int smsCount;
	/**折扣信息，显示给用户看的*/
	private String discount;

	public String getChargeId() {
		return chargeId;
	}

	public void setChargeId(String chargeId) {
		this.chargeId = chargeId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSmsCount() {
		return smsCount;
	}

	public void setSmsCount(int smsCount) {
		this.smsCount = smsCount;
	}

	public String getDiscountInfo() {
		return discount;
	}

	public void setDiscountInfo(String discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "ChargeInfoSMS[chargeId="
				+ chargeId +  ", price="
				+ price +  ", count=" + smsCount
				+ ", discount=" + discount + "]";
	}

}
