package com.zyiot.sdk.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * 设备检测升级时相关字段的封装
 * @author cxm
 */
public class DevUpdateEntity implements Parcelable {

    /**设备类型Id*/
    private int devTypeId;

    /** 设备Keyhash */
    private String keyhash;

    /** 设备升级进度（0-100），升级完成时是100*/
    private int percentage;

    /** 是否需要强制升级，true表示需要强制升级，升级了固件才可以正常运行 */
    private boolean forceUpdate;

    /** 是否最新，true表示固件已经最新，无新版本*/
    private boolean isNewest;//

    /** 设备名称（预留，暂不支持）  */
    private String devName;

    /** 进度更新时间，升级过程中的每一次进度变化的时间戳，单位：毫秒 */
    private long timestamp;

    /** 固件当前版本 */
    private  String versionCurrent;

    /** 固件最新版本 */
    private  String versionNewest;

    public  DevUpdateEntity(){}

    public DevUpdateEntity(String keyhash,boolean isNewest,boolean forceUpdate,int percentage){
        this.keyhash=keyhash;
        this.isNewest=isNewest;
        this.forceUpdate=forceUpdate;
        this.percentage=percentage;
    }


    protected DevUpdateEntity(Parcel in) {
        devTypeId = in.readInt();
        keyhash = in.readString();
        percentage = in.readInt();
        forceUpdate = in.readByte() != 0;
        isNewest = in.readByte() != 0;
        devName = in.readString();
        timestamp = in.readLong();
    }

    public static final Creator<DevUpdateEntity> CREATOR = new Creator<DevUpdateEntity>() {
        @Override
        public DevUpdateEntity createFromParcel(Parcel in) {
            return new DevUpdateEntity(in);
        }

        @Override
        public DevUpdateEntity[] newArray(int size) {
            return new DevUpdateEntity[size];
        }
    };

    public int getDevTypeId() {
        return devTypeId;
    }

    public void setDevTypeId(int devTypeId) {
        this.devTypeId = devTypeId;
    }

    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public int getPercentage() {
        return percentage;
    }

    public void setPercentage(int percentage) {
        this.percentage = percentage;
    }

    public boolean isForceUpdate() {
        return forceUpdate;
    }

    public void setForceUpdate(boolean forceUpdate) {
        this.forceUpdate = forceUpdate;
    }

    public boolean isNewest() {
        return isNewest;
    }

    public void setIsNewest(boolean isNewest) {
        this.isNewest = isNewest;
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(String devName) {
        this.devName = devName;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getVersionCurrent() {
        return versionCurrent;
    }

    public void setVersionCurrent(String versionCurrent) {
        this.versionCurrent = versionCurrent;
    }

    public String getVersionNewest() {
        return versionNewest;
    }

    public void setVersionNewest(String versionNewest) {
        this.versionNewest = versionNewest;
    }

    @Override
    public String toString() {
        return  keyhash+" newest="+isNewest+" force="+forceUpdate ;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(devTypeId);
        dest.writeString(keyhash);
        dest.writeString(versionCurrent);
        dest.writeString(versionNewest);
        dest.writeInt(percentage);
        dest.writeByte((byte) (forceUpdate ? 1 : 0));
        dest.writeByte((byte) (isNewest ? 1 : 0));
        dest.writeString(devName);
        dest.writeLong(timestamp);
    }
}
