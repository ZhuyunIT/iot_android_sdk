package com.zyiot.sdk.entity;

import java.io.Serializable;

/**设备属性
 * @author cxm
 */
public class DeviceAttr implements Serializable{

	/**属性名*/
	private String name;

	/**属性值*/
	private String value;

	/**属性变化时间戳（单位：毫秒）*/
	private long timestamp;

	public DeviceAttr() {
		// TODO Auto-generated constructor stub
	}
	 

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	 

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return " {name=" + name + ":"+value+"}";

	}

}
