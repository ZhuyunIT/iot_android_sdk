package com.zyiot.sdk.entity;

import java.io.Serializable;

/***
 * 筑云消息中心的消息
 * @author cxm
 */
public class MessageCenterMsg implements Serializable,Comparable<MessageCenterMsg>{

	/**发布时间，按时间戳降序排序*/
	private long newstime;

	/**起始时间*/
	private long startTime;

	/**过期时间*/
	private long expireTime;

	/**消息标题*/
	private String title;

	/**消息内容*/
	private String content;

	/** 针对的设备类型Id，如果有多个设备类型，用英文符号分号“;”隔开，如“1;21”表示本消息与设备类型1和21有关。如果为0，说明针对所有设备类型。*/
	private String devTypeId;

	/**消息类型Id*/
	private int msgTypeId;

	public long getNewstime() {
		return newstime;
	}

	public void setNewstime(long newstime) {
		this.newstime = newstime;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDevTypeId() {
		return devTypeId;
	}

	public void setDevTypeId(String devTypeId) {
		this.devTypeId = devTypeId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getMessageTypeId() {
		return msgTypeId;
	}

	public void setMessageTypeId(int msgTypeId) {
		this.msgTypeId = msgTypeId;
	}

	public long getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(long expireTime) {
		this.expireTime = expireTime;
	}

	public long getStartTime() {
		return startTime;
	}

	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}



	@Override
	public String toString() {
		return "Message [newstime=" + newstime + ", startTime="
				+ startTime + ", expireTime=" + expireTime + ", title=" + title
				+ ", content=" + content + ", devTypeId=" + devTypeId
				+ ", msgTypeId=" + msgTypeId + "]";
	}

	@Override
	public int compareTo(MessageCenterMsg another) {
		// TODO Auto-generated method stub
		if(newstime==another.newstime){
			return 0;
		}
		return (int) (newstime-another.newstime);
	}



	
}
