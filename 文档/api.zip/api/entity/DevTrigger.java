package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 设备触发器，当本类型的设备的属性值变化时，按照如下配置后台执行。
 *
 * @author cxm
 */
public class DevTrigger implements Serializable {


    /**
     * 触发器标识
     */
    private String triggerId;

    /**
     * 设备类型ID
     */
    private String devTypeId;


    /**
     * 属性名
     */
    private String attrName;

    /**
     * 当被触发时，是否推送，默认false不推送
     */
    private boolean isPush;

    /**
     * 当被触发的行为发生时，是否将行为存储为log历史记录，默认false不存储
     */
    private boolean isSave;

    /**
     * 历史记录存储时间，单位：天，默认7天，如果购买套餐则以套餐时间为准
     */
    private int saveTime;

    /**
     * 是否抓拍，默认false不抓拍。（需要触发器的isSave=true且设备已绑定摄像头时才有效，将调用设备属性的camera中摄像头token抓拍图片。）
     */
    private boolean isCapture;

    /**
     * 相关用户类型，指的是可查看被触发后产生的历史记录的用户群
     * 0仅管理员；1管理员与二级用户；2所有用户，默认为1。
     */
    private String relatedUserType;

    /**
     * 触发器类型，0默认，达到条件就触发；1阈值恢复，第一次满足条件时触发，下一次由false变为true时触发——满足触发条件时为true，否则为false；2自动失效，触发一次后自动失效，只有再打开后才生效(用户可以设置开启或关闭)。
     * 如阈值恢复：检测设备电池电量，当用户设备自定义触发器时设定设备低于20%时触发——只在第一次低于20%时触发，如果后续一直低于20%，不再触发。只有充电后电量高于20%后，再低于20%才会触发。
     */
    private String type;

    public DevTrigger() {
        // TODO Auto-generated constructor stub
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getDevTypeId() {
        return devTypeId;
    }

    public void setDevTypeId(String devTypeId) {
        this.devTypeId = devTypeId;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public boolean isPush() {
        return isPush;
    }

    public void setPush(boolean push) {
        isPush = push;
    }

    public boolean isSave() {
        return isSave;
    }

    public void setSave(boolean save) {
        isSave = save;
    }

    public int getSaveTime() {
        return saveTime;
    }

    public void setSaveTime(int saveTime) {
        this.saveTime = saveTime;
    }

    public boolean isCapture() {
        return isCapture;
    }

    public void setCapture(boolean capture) {
        isCapture = capture;
    }

    public String getRelatedUserType() {
        return relatedUserType;
    }

    public void setRelatedUserType(String relatedUserType) {
        this.relatedUserType = relatedUserType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "DevTrigger [Id=" + triggerId +",devTypeId="+devTypeId+ ",type=" + type
                +",attr="+attrName +",relateU=" +relatedUserType+",isSave=" +isSave+",saveT="+saveTime+",isPush="+isPush+",isCapture="+isCapture+ "]";
    }

}
