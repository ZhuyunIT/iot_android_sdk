package com.zyiot.sdk.entity;

import com.zyiot.sdk.utils.AboutTime;
import com.zyiot.sdk.utils.StrParseToNum;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**本实体类是对临时用户权限的封装。
 * type=0时段年月日日期（时间戳内）；1单次时段年月日日期（时间戳内，只允许控制一次设备，控制后权限失效）
 *
 * 权限说明，包含两种类型，一种是时段控制，一种是时段单次控制（控制后即失效）。
 * 时段控制格式如下：{"type": "0","time": "12345-23456","shareTime": "12345"}；时段单次控制格式如下：{"type": "1","time": "12345-23456","controlTime": "22345","shareTime": "12345"}。
	 type为0表示时段控制，为1表示时段单次控制。
 	time包含起始和结束时间戳，中间用-隔开，精确到秒。
 	controlTime为操控时间，只针对时段单次控制有效，如果control_time为空，表示未操控，为时间戳表示操控时间。
 	shareTime为临时用户分享时间。
 	所有字段都为String格式。
 时间戳单位是秒
 * @author cxm
 *
 */
public class AuthorityTempEntity implements Serializable {
	/**
	 * type=0时段年月日日期（时间戳内）；
	 * 1单次时段年月日日期（时间戳内，只允许控制一次设备，控制后权限失效）
	 *
	 */
	private int validType;


	/**临时用户权限被创建的时间，单位：秒
	 */
	private long shareTime;

	/**
	 * 使用权限控制设备的时间，（预留），单位：秒
	 */
	private long controlTime;


	/**timestamp1是起始时间日期，timestamp2终止时间日期
	 * timestamp1-timestamp2是年月日时间点时间戳区间，不可重复
	 * 时间戳单位：秒
	 */
	private long timestamp1;
	private long timestamp2;


	public AuthorityTempEntity(int type){
		super();
		validType=type;
	}
	public AuthorityTempEntity(String json){
		super();
		initAuthorityJSON(json);
	}

	public int getValidType() {
		return validType;
	}

	public void setValidType(int validType) {
		this.validType = validType;
	}
	public long getShareTime() {
		return shareTime;
	}

	public void setShareTime(long setValidTime) {
		this.shareTime = setValidTime;
	}

	public long getControlTime() {
		return controlTime;
	}

	public void setControlTime(long controlTime) {
		this.controlTime = controlTime;
	}

	public long getTimestamp1() {
		return timestamp1;
	}

	public void setTimestamp1(long timestamp1) {
		this.timestamp1 = timestamp1;
	}

	public long getTimestamp2() {
		return timestamp2;
	}

	public void setTimestamp2(long timestamp2) {
		this.timestamp2 = timestamp2;
	}

	/**
	 * @param time :time格式是“12:20”
	 * @return:秒数
	 */
	public int getSecondFromTime(String time){
		if(time==null||time.split(":").length!=2){
			return 0;
		}else{
		String[] ts=	time.split(":");
		 int hour=StrParseToNum.parseToInt(ts[0], 0);
		 int minute=StrParseToNum.parseToInt(ts[1], 0);
		 return (hour*60*60+minute*60);
		}
	}

	public String getJsonStrAuthorityDescription() {
		return getAuthorityJSON().toString();
	}

	public JSONObject getAuthorityJSON() {
		JSONObject jsob=new JSONObject();
		try {
			long t1=timestamp1;
			long t2=timestamp2;
			if(t1>1000000000000L){//转秒
				t1=timestamp1/1000;
			}
			if(t2>1000000000000L){//转秒
				t2=timestamp2/1000;
			}
			jsob.put("time",t1+"-"+t2);
			jsob.put("type",""+validType);
			if(shareTime>0){
				jsob.put("shareTime",shareTime);
			}
			if(controlTime>0){
				jsob.put("controlTime",controlTime);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsob;
	}
	/**根据JSON内容生成权限封装*/
	public AuthorityTempEntity initAuthorityJSON(String jsonStr) {
		if(jsonStr==null||jsonStr.trim().length()==0){
			return null;
		}
		try {
			JSONObject jsob=new JSONObject(jsonStr);
			int validType=jsob.optInt("type");
			AuthorityTempEntity auth=this;
			auth.setValidType(validType);
			long controlTime=jsob.optLong("controlTime",0);
			long shareTime=jsob.optLong("shareTime",0);
			auth.setShareTime(shareTime);
			auth.setControlTime(controlTime);
			String ts=jsob.optString("time");
			String[] timeStrs=null;
			if(ts!=null&&ts.trim().contains("-")){
				timeStrs=ts.split("-");
			}
			if(timeStrs.length>=2){
				long timestamp1=StrParseToNum.parseToLong( timeStrs[0],0);
				long timestamp2=StrParseToNum.parseToLong( timeStrs[1],0);
				auth.setTimestamp1(timestamp1);
				auth.setTimestamp2(timestamp2);
			}
			return auth;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return this;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "TempAuthority[type="+validType + ", shareT="+shareTime+",controlT="+controlTime+"]";
	}
}

