package com.zyiot.sdk.entity;

import com.zyiot.sdk.utils.AboutTime;
import com.zyiot.sdk.utils.StrParseToNum;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**本实体类是对二级用户权限的封装。
 * 权限包含字段说明：type：操控类型，0表示全时访问-不限制时间，无需time区间和week；1表示时段访问，无需week；2表示定期访问。time表示操控设备的时间区间，如果是时段访问，内容为年月日日期的起始-结束时间戳(单位：秒)，中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。shareTime表示分享时间，为时间戳（单位秒）。
 形如：{"type":"2","time":"12345-23456","week":"146","shareTime":"1567898770"}
 *
 * @author cxm
 * type=0（全时）； 1年月日日期（时间戳内）；2时间点（每周重复）
 *
 */
public class AuthorityEntity implements Serializable {
	/**0表示全时访问，不限制时间，无需time和week；
	 * 1表示时段访问，无需week，需要设置time（时间戳单位是秒）；
	 * 2表示定期访问，需要设置week、time
	 * 
	 */
	private int validType;
	

	/**二级用户权限被创建的时间，单位：秒
	 */
	private long shareTime;

	/**
	 * 使用权限控制设备的时间，（预留），单位：秒
	 */
	private long controlTime;

	public AuthorityEntity(int type){
		super();
		validType=type;
	}

	public int getValidType() {
		return validType;
	}

	public void setValidType(int validType) {
		this.validType = validType;
	}



	/**
	 * @param time :time格式是“12:20”
	 * @return:秒数
	 */
	public int getSecondFromTime(String time){
		if(time==null||time.split(":").length!=2){
			return 0;
		}else{
		String[] ts=	time.split(":");
		 int hour=StrParseToNum.parseToInt(ts[0], 0);
		 int minute=StrParseToNum.parseToInt(ts[1], 0);
		 return (hour*60*60+minute*60);
		}
	}
	/**按照指定模式获取时间：yyyy-MM-dd HH:mm
	 * @param timestamp
	 * @return
	 */
	public String getTimStrFromTimestamp(long timestamp){
		return 	AboutTime.getFormatTimeFromPatternByTimestamp(timestamp, "yyyy-MM-dd HH:mm");
	}

	public long getShareTime() {
		return shareTime;
	}

	public void setShareTime(long setValidTime) {
		this.shareTime = setValidTime;
	}

	public long getControlTime() {
		return controlTime;
	}

	public void setControlTime(long controlTime) {
		this.controlTime = controlTime;
	}




	public String getJsonStrAuthorityDescription() {
		return getAuthorityJSON().toString();
	}

	public JSONObject getAuthorityJSON() {
		JSONObject jsob=new JSONObject();
		try {
			if(validType==0){
				jsob.put("type","0");
			}else if(validType==1){
				jsob.put("type","1");
				if(this instanceof AuthorityEntity1){
					AuthorityEntity1 auth1= (AuthorityEntity1) this;
					jsob.put("time",auth1.getTimestamp1()+"-"+auth1.getTimestamp2());
				}
			}else if(validType==2){
				jsob.put("type","2");
				if(this instanceof AuthorityEntity2){
					AuthorityEntity2 auth2= (AuthorityEntity2) this;
					jsob.put("time",auth2.getTime1()+"-"+auth2.getTime2());
					jsob.put("week",auth2.getWeekMode());
				}
			}
			if(shareTime>0){
				jsob.put("shareTime",shareTime);
			}
			if(controlTime>0){
				jsob.put("controlTime",controlTime);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsob;
	}
	/**根据JSON内容生成权限封装*/
	public static AuthorityEntity initAuthorityJSON(String jsonStr) {
		if(jsonStr==null||jsonStr.trim().length()==0){
			return null;
		}
		try {
			JSONObject jsob=new JSONObject(jsonStr);
			int validType=jsob.optInt("type");
			AuthorityEntity auth=null;
			if(validType==1){
				auth=new AuthorityEntity1();
			}else if(validType==2){
				auth=new AuthorityEntity2();
			}else{
				auth=new AuthorityEntity(validType);
			}
			long controlTime=jsob.optLong("controlTime",0);
			long shareTime=jsob.optLong("shareTime",0);
			auth.setShareTime(shareTime);
			auth.setControlTime(controlTime);
			if(validType!=0){
				String ts=jsob.optString("time");
				String weekMode=jsob.optString("week");
				String[] timeStrs=null;
				if(ts!=null&&ts.trim().contains("-")){
					 timeStrs=ts.split("-");
				}
				if(validType==1){
					if(auth instanceof AuthorityEntity1){
						AuthorityEntity1 auth1= (AuthorityEntity1) auth;
						if(timeStrs.length>=2){
							long timestamp1=StrParseToNum.parseToLong( timeStrs[0],0);
							long timestamp2=StrParseToNum.parseToLong( timeStrs[1],0);
							auth1.setTimestamp1(timestamp1);
							auth1.setTimestamp2(timestamp2);
						}
					}
				}
				if(validType==2){
					if(auth instanceof AuthorityEntity2){
						AuthorityEntity2 auth2= (AuthorityEntity2) auth;
						auth2.setWeekMode(weekMode);
						if(timeStrs.length>=2){
							int time1=StrParseToNum.parseToInt( timeStrs[0],0);
							int time2=StrParseToNum.parseToInt( timeStrs[1],0);
							auth2.setTime1(time1);
							auth2.setTime2(time2);
						}
					}
				}
			}
			return auth;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Authority[type="+validType + ", shareT="+shareTime+",controlT="+controlTime+"]";
	}
}

