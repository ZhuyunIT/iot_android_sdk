package com.zyiot.sdk.entity;

import com.zyiot.sdk.utils.StrParseToNum;

import java.io.Serializable;

/**
 * 属性的值定义，包括属性不同取值时的文字含义——含中英文
 */
@SuppressWarnings("serial")
public class DevAttrOperation implements Serializable {
    /**
     * 属性定义ID
     */
    private String operId;

    /**
     * 操作内容，属性作为触发条件时的属性定义，json数据。根据不同的属性值类型，有不同的定义，
     * 如int时：{"intC": {"defaultV": 20,"max": 10,"min": 40,
     * "==": {"en": "temperature equal(℃)","zh": "温度等于（度）"},
     * "<": {"en": "temperature lower(℃)","zh": "温度小于（度）"},
     * ">": {"en": "temperature Upper(℃)","zh": "温度大于（度）"}
     * }}
     * 具体定义详见属性定义JSON说明文档。
     */
    private String operation;

    /**
     * 属性名
     */
    private String attrName;

    /**
     * 定时执行的属性值定义，json数据。根据不同的属性值类型，有不同的定义，如int时：{
     * "intVas": { "defaultV": 50,"lang": {"en": "temperature(℃)","zh": "温度(度)"},"max": 80,"min":10}}
     * 具体定义详见属性定义JSON说明文档。
     */
    private String attrValue;

    public String getOperId() {
        return operId;
    }

    public void setOperId(String operId) {
        this.operId = operId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public String getAttrValue() {
        return attrValue;
    }

    public void setAttrValue(String attrValue) {
        this.attrValue = attrValue;
    }

    @Override
    public String toString() {
        return "AttrOpe[id="+operId+",name="+attrName+",vas="+attrValue+",cons="+operation+"]";
    }
}
