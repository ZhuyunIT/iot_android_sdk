package com.zyiot.sdk.entity;

import java.io.Serializable;

/***
 * 筑云消息中心被删除的消息（有的消息被消息中心删除了需要APP也删除本地缓存）
 * @author cxm
 */
public class MessageCenterMsgDelete implements Serializable,Comparable<MessageCenterMsgDelete>{

	/**发布时间，按时间戳降序排序*/
	private long newstime;

	/**消息类型id*/
	private int msgTypeId;

	/**是否应该删除本地数据库记录,1表示要删除*/
	private int isDelete;

	public long getNewstime() {
		return newstime;
	}

	public void setNewstime(long newstime) {
		this.newstime = newstime;
	}


	public int getMessageTypeId() {
		return msgTypeId;
	}

	public void setMessageTypeId(int msgTypeId) {
		this.msgTypeId = msgTypeId;
	}


	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}

	@Override
	public String toString() {
		return "MessageDelete [ newstime=" + newstime + ", isDelete="
				+ isDelete  +", msgTypeId=" + msgTypeId + "]";
	}

	@Override
	public int compareTo(MessageCenterMsgDelete another) {
		// TODO Auto-generated method stub
		if(newstime==another.newstime){
			return 0;
		}
		return (int) (newstime-another.newstime);
	}



	
}
