package com.zyiot.sdk.entity;

import java.io.Serializable;

/** 用户token类，对应facebook授权登录时token的解析情况
 * @author cxm
 */
public class ZYUserTokenFacebook implements Serializable{

	/**用户唯一标识，用户注册筑云平台后生成的*/
	private String userId;

	/**facebook授权的userId，一个用户标识。*/
	private String facebookOauthUserId;

	/* 用户登录后记录状态的令牌标识，本Token未过期时可用本令牌刷新得到新筑云token
	facebook服务器返回的Token，可以用于验证facebook用户是否合法 （本Token是facebook的Token，可用于facebook API，也用于筑云API-facebookOauthAutoLogin可刷新筑云Token）
	*/
	private String facebookToken;

	/** 筑云Token，用户登录筑云成功后的Token令牌（本Token用于筑云API） */
	private String token;

	/**  上次登录时间（时间戳，单位：秒） */
	private long lastLoginTime;

	/** 上次登录方式  0：账号密码登录 1：微信授权登录 2：facebook授权登录 */
	private String lastLoginWay;

	/** 上次登录手机型号 */
	private String lastLoginPhoneType;



	public ZYUserTokenFacebook() {
	// TODO Auto-generated constructor stub
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFacebookOauthUserId() {
		return facebookOauthUserId;
	}

	public void setFacebookOauthUserId(String facebookOauthUserId) {
		this.facebookOauthUserId = facebookOauthUserId;
	}

	public String getFacebookToken() {
		return facebookToken;
	}

	public void setFacebookToken(String facebookToken) {
		this.facebookToken = facebookToken;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public long getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(long lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getLastLoginWay() {
		return lastLoginWay;
	}

	public void setLastLoginWay(String lastLoginWay) {
		this.lastLoginWay = lastLoginWay;
	}

	public String getLastLoginPhoneType() {
		return lastLoginPhoneType;
	}

	public void setLastLoginPhoneType(String lastLoginPhoneType) {
		this.lastLoginPhoneType = lastLoginPhoneType;
	}

	@Override
	public String toString() {
		return "ZYUserToken [userId=" + userId + ", userToken=" + token
				+ "]";
	}

}
