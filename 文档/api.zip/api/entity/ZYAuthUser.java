package com.zyiot.sdk.entity;

import java.io.Serializable;

/** 筑云二级用户（设备的二级用户）
 * @author cxm
 */
public class ZYAuthUser implements Serializable, Comparable<ZYAuthUser> {
	/**用户唯一标识，用户注册后生成的*/
	private String authUserId;

	/** 权限级别，1是一级用户-管理员操控设备无时间限制，2是二级用户操控设备的时间权限由管理员设定*/
	private int level;

	/**权限说明，json格式数据，包含字段说明：type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week，需要time；2表示定期访问。time表示允许操控的时间区间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。shareTime表示分享时间，为时间戳（单位：秒）。
	 形如：{"type":"2","time":"12345-23456","week":"146","shareTime":"1567898770"}*/
	private AuthorityEntity authority;

	/**用户绑定的手机号码*/
	private String phoneNum;

	/**用户绑定的邮箱 */
	private String email;

	/**用户昵称备注*/
	private String nickname;

	/**用户头像图片名称*/
	private String headProtrait;

	/**管理员为二级用户备注*/
	private String remark;

	public ZYAuthUser() {
		// TODO Auto-generated constructor stub
	}

	public ZYAuthUser(String userId, String email, String phone, String nickname,int level,AuthorityEntity authority) {
		// TODO Auto-generated constructor stub
		this.authUserId = userId;
		this.email = email;
		this.phoneNum = phone;
		this.nickname = nickname;
		this.level=level;
		this.authority=authority;
	}

	public String getAuthUserId() {
		return authUserId;
	}

	public void setAuthUserId(String authUserId) {
		this.authUserId = authUserId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public AuthorityEntity getAuthority() {
		return authority;
	}

	public void setAuthority(AuthorityEntity authority) {
		this.authority = authority;
	}
	public void setAuthority(String authorityJsonStr) {
		AuthorityEntity valid=AuthorityEntity.initAuthorityJSON(authorityJsonStr);
		this.authority = valid;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getHeadProtrait() {
		return headProtrait;
	}

	public void setHeadProtrait(String headProtrait) {
		this.headProtrait = headProtrait;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "ZYAuthUser [userid=" + authUserId + ", phonenum=" + phoneNum + ", email=" + email + ",  level="
				+ level + ", authority=" + authority + "]";
	}

	@Override
	public int compareTo(ZYAuthUser another) {
		// TODO Auto-generated method stub
		ZYAuthUser other = (ZYAuthUser) another;
		int otherLevle = other.getLevel();
//		// note: enum-type's comparation depend on types' list order of enum
//		// method
//		// so, if compared property is enum-type ,then its comparationfollow
//		// ObjEnum.objType order
		return otherLevle-this.getLevel() ;
//		 return 0;
	}

}
