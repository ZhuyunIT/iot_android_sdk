package com.zyiot.sdk.entity;

import java.io.Serializable;

/**筑云临时用户（该类临时用户不需要账号登录，可通过网页控制APP）
 * @author cxm
 */
public class ZYTempUser implements Serializable  {
	/**用户唯一标识，用户被分享后生成的*/
	private String tempShareId;

	/**权限说明，JSON数据格式，包含两种，一种是时段控制，一种是时段单次控制（控制后即失效）。格式为json格式。时段控制格式如下：{"type": "0","time": "12345-23456","shareTime": "12345"}；时段单次控制格式如下：{"type": "1","time": "12345-23456","controlTime": "22345","shareTime": "12345"}。
	   type为0表示时段控制，为1表示时段单次控制。
	  time包含起始和结束时间戳，中间用-隔开，精确到秒。
	   controlTime为操控时间，只针对时段单次控制有效，如果control_time为空，表示未操控，为时间戳表示操控时间。
	   shareTime为临时用户分享时间。
	   所有字段都为String格式。
	   时间戳单位是秒
	 */
	private AuthorityTempEntity authority;

    /**管理员为临时用户备注*/
	private String remark;
    
	public ZYTempUser() {
		// TODO Auto-generated constructor stub
	}

	public ZYTempUser(String tempShareId, String authority,  String remark ) {
		// TODO Auto-generated constructor stub
		this.tempShareId = tempShareId;
		this.authority = new AuthorityTempEntity(0).initAuthorityJSON(authority);
		this.remark = remark;
	}

	public String getTempShareId() {
		return tempShareId;
	}

	public void setTempShareId(String tempShareId) {
		this.tempShareId = tempShareId;
	}

	public AuthorityTempEntity getAuthority() {
		return authority;
	}

	public void setAuthority(AuthorityTempEntity authority) {
		this.authority = authority;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "ZYAuthUser [Id=" + tempShareId + ", remark=" + remark + ", authority=" + authority + "]";
	}


}
