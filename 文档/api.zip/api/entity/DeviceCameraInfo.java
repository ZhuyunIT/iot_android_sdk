package com.zyiot.sdk.entity;

import java.io.Serializable;

/**设备绑定的摄像头信息封装如下：（如萤石摄像头）
 * @author cxm
 */
public class DeviceCameraInfo implements Serializable{

	/**摄像头ID，摄像头设备标识*/
	private String cameraId;

	/**摄像头视频数据的原密码，设备说明书上标注的摄像头默认验证码（密码）。如果摄像头的拥有者没有修改摄像头的密码，则此密码有效，视频被加密可用此密码解密获取到的视频数据 */
	private String originalPassword;

	/**摄像头视频数据的密码，如果摄像头的拥有者修改了摄像头的密码，则原密码无效，应使用本密码解密获取的被加密视频数据 */
	private String password;

	/**摄像头型号（预留，暂不支持）*/
	private String type;

	/**萤石用户的accessToken，绑定摄像头时请先调用萤石相关接口检查当前萤石SDK内在登用户是否拥有这个摄像头。
	 * APP使用萤石SDK需要先设置这个值才可以操作摄像头，如查看摄像头。
	 * 后台保存accessToken值是为了共享摄像头，不需要在不同的手机萤石重复授权登录筑云*/
	private String  accessToken;


	public DeviceCameraInfo() {
		// TODO Auto-generated constructor stub
	}

	public String getCameraId() {
		return cameraId;
	}

	public void setCameraId(String cameraId) {
		this.cameraId = cameraId;
	}

	public String getOriginalPassword() {
		return originalPassword;
	}

	public void setOriginalPassword(String originalPassword) {
		this.originalPassword = originalPassword;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	@Override
	public String toString() {
		return " Camera{id=" + cameraId + ",originalPwd="+originalPassword+",pwd="+password+",accessToken="+accessToken+"}";
	}

}
