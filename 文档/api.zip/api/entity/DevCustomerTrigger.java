package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 设备自定义触发器，是设备触发器的拓展——设备触发器针对设备类型下的所有设备，设备自定义触发器针对指定设备。
 * 不同用户可以根据自身需求设定不同的属性值，进行推送。比如，婴儿体温计A用户设置>37度才触发；B用户设置>38度触发；C用户未设置。那么C用户的温度计只要温度变化都将收到推送通知(此时未自定义，则使用设备触发器默认配置)，A用户在大于37时会收到通知，B用户在大于38时会收到通知
 *
 * @author cxm
 */
public class DevCustomerTrigger implements Serializable {


    /**
     * 触发器标识
     */
    private String triggerId;

    /**
     * 设备类型ID
     */
//    private String devTypeId;

    /**
     * 设备标识
     */
    private String keyhash;

    /**
     * 属性名
     */
    private String attrName;
    /**
     * 触发状态，是否可触发，默认true可触发
     */
    private boolean status;
    /**
     * 时间限制，json格式数据： type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。
     * 形如：{"type":"2","time":"12345-23456","week":"127"}
     */
    private String timelimit;
    /**
     * 触发条件——属性值条件判断。json格式数据，包含operation，threshold。operation：触发条件，包括：>，<，>=，<=，==，!=，contains，equals。threshold：阈值。
     * 形如：{"operation":">","threshold":"20"}
     */
    private String condition;
    /**
     * 备注
     */
    private String remark;

    public DevCustomerTrigger() {
        // TODO Auto-generated constructor stub
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }



    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public String getAttrName() {
        return attrName;
    }

    public void setAttrName(String attrName) {
        this.attrName = attrName;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getTimelimit() {
        return timelimit;
    }

    public void setTimelimit(String timelimit) {
        this.timelimit = timelimit;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "DevCustomerTrigger[Id=" + triggerId + ",attr=" + attrName
           +",status="+status+",dev="+keyhash+",con="+condition+",t="+timelimit +",remark="+remark    + "]";
    }

}
