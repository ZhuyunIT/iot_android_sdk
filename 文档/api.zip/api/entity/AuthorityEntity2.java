package com.zyiot.sdk.entity;

import android.text.TextUtils;

import com.zyiot.sdk.utils.AboutTime;
import com.zyiot.sdk.utils.StrParseToNum;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;

/**本实体类是对二级用户权限(定期访问权限)的封装——2 :周重复模式（每周重复时间点）
 * @author cxm
 *
 */
public class AuthorityEntity2 extends AuthorityEntity implements Serializable {
	/**time1-time2是时间点区间，可重复（每天时间有24小时，取值范围是0-86400）
	 */
	private int time1;
	private int time2;
	/**week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日*/
	private String weekMode;


	public AuthorityEntity2( ){
		super(2);
	}

	@Override
	public int getValidType() {
		return 2;
	}

	public int getTime1() {
		return time1;
	}

	public void setTime1(int time1) {
		this.time1=time1;
	}

	/**权限开始时间：某天中的某个时间点(时辰:分钟，如 8:18)
	 * @param time1
	 */
	public void setTime1(String time1) {
		this.time1 = getSecondFromTime(time1);
	}

	public int getTime2() {
		return time2;
	}
	public void setTime2(int time2) {
		this.time2=time2;
	}
	/**权限结束时间：某一天中的某个时间点（时辰:分钟，如12:30）
	 * @param time2
	 */
	public void setTime2(String time2) {
		this.time2 = getSecondFromTime(time2);
	}


	public String getWeekMode() {
		if(TextUtils.isEmpty(weekMode) ){
			return "";
		}
		return weekMode;
	}

	public void setWeekMode(String weekMode) {
		this.weekMode = weekMode;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Authority2[type="+getValidType() + ",t1=" + time1 + ",t2=" + time2 + ",weekMode=" + weekMode+",shareT="+getShareTime()+"]";
	}
}

