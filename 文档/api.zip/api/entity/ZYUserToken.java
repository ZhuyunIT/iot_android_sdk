package com.zyiot.sdk.entity;

import java.io.Serializable;

/** 用户token类，对应登录时token的解析情况
 * @author cxm
 */
public class ZYUserToken implements Serializable{
	/**用户唯一标识，用户注册后生成的*/
	private String userId;

	/**筑云Token，用户登录筑云成功后的Token令牌（本Token用于筑云API） */
	private String token;

	/**用户登录后记录状态的令牌标识，本refreshToken未过期时可用本令牌刷新得到新token*/
	private String refreshToken;

	/**用户上次登录的时间（单位：秒）*/
	private long lastLoginTime;

	/**用户上次登录的机型*/
	private String lastLoginPhoneType;

	/**用户上次登录的方式：0账号密码登录；1微信授权登录；2Facebook登录*/
	private String lastLoginWay;

	public ZYUserToken() {
		// TODO Auto-generated constructor stub
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public long getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(long lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getLastLoginPhoneType() {
		return lastLoginPhoneType;
	}

	public void setLastLoginPhoneType(String lastLoginPhoneType) {
		this.lastLoginPhoneType = lastLoginPhoneType;
	}

	public String getLastLoginWay() {
		return lastLoginWay;
	}

	public void setLastLoginWay(String lastLoginWay) {
		this.lastLoginWay = lastLoginWay;
	}

	@Override
	public String toString() {
		return "ZYUserToken [userId=" + userId + ", userToken=" + token
				+ "]";
	}


}
