package com.zyiot.sdk.entity;

import java.io.Serializable;

import com.zyiot.sdk.utils.StrParseToNum;

/**筑云用户（注册的用户）
 * @author cxm
 */
public class ZYUser implements Serializable {

	/** 登录后的用户令牌*/
	private String token;

	/** 登录状态保持*/
	private String refreshToken;

	/**用户唯一标识，用户注册后生成的*/
	private String userId;

	/**用户绑定的手机号码*/
	private String phoneNum;

	/**用户绑定的邮箱 */
	private String email;

	/**用户昵称备注*/
	private String nickname;

	/**用户头像图片名称*/
	private String headProtrait;

	/**用户绑定微信公众号的关系字段，有值则表示已绑定公众号（若想收到微信推送，则需要先调用接口绑定公众号）*/
	private String wechatPublicOpenid;

/** 用户授权微信登录，本字段有值则表示已授权，可以通过微信授权的账号登录本用户*/
//	private String wechatOauthOpenid;
/**用户授权Facebook登录，本字段有值表示已授权，可以通过Facebook授权的账号登录本用户*/
//	private String facebookOauth;

	/**用户的短信发送次数，如找回密码、修改账号功能可能需要发送短信，可以提示用户绑定邮箱，避免短信次数用完影响APP使用。*/
	private String smsRemain;

	/**用户登录的手机keyhash，用于标识用户登录的手机，在控制设备时有鉴权。*/
	private String keyhash;

	/**消息中心推送开关，默认true，true表示允许收到来自筑云消息中心的消息推送，false表示不接受推送。*/
	private boolean msgSwitch;

	/**设备操控记录的总推送开关，默认true，true表示允许收到设备操控记录推送，false表示不接受推送。*/
	private boolean pushSwitch;

	/**微信-设备操控记录的推送开关，默认true，true表示允许微信收到设备操控记录推送，false表示不接受推送。*/
	private boolean wechatSwitch;

	/**邮箱-设备操控记录的推送开关，默认true，true表示允许邮箱收到设备操控记录推送，false表示不接受推送。*/
	private boolean emailSwitch;

	/**手机推送类型，android_0表示百度云推送，android_1表示gcm推送*/
	private String phonePush;

	/**推送通道ID，iOS的channelId是devuceToken*/
	private String channelId;

	/**消息免打扰时间段，在这个时间内所有推送消息都关闭。单位：秒(一天中的秒数)，中间用“-”分隔(如12345-86300)，如果结束时间小于起始时间说明是第二天。*/
	private String noDisturbTime;

	/**个性铃声 */
	private String ring;

	/**手机上的语种，可用于决定设备管理员收到的推送内容的语种，目前支持中文、英文。*/
	private String language;

	/**待定保留字段，个人信息*/
	private String personalInfo;

	/**字体大小*/
	private String fontSize;

	/**用户上次登录的时间*/
	private String lastLoginTime;

	/**用户上次登录的机型*/
	private String lastLoginPhoneType;

	/**用户上次登录的方式：0账号密码登录；1微信授权登录；2Facebook登录*/
	private String lastLoginWay;

	public ZYUser() {
		// TODO Auto-generated constructor stub
	}

	public ZYUser(String userId, String email, String phone,String nickname) {
		// TODO Auto-generated constructor stub
		this.userId = userId;
		this.email = email;
		this.phoneNum = phone;
		this.nickname = nickname;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getHeadProtrait() {
		return headProtrait;
	}

	public void setHeadProtrait(String headProtrait) {
		this.headProtrait = headProtrait;
	}

	public String getWechatPublicOpenid() {
		return wechatPublicOpenid;
	}

	public void setWechatPublicOpenid(String wechatPublicOpenid) {
		this.wechatPublicOpenid = wechatPublicOpenid;
	}
/*

	public String getWechatOauthOpenid() {
		return wechatOauthOpenid;
	}

	public void setWechatOauthOpenid(String wechatOauthOpenid) {
		this.wechatOauthOpenid = wechatOauthOpenid;
	}

	public String getFacebookOauth() {
		return facebookOauth;
	}

	public void setFacebookOauth(String facebookOauth) {
		this.facebookOauth = facebookOauth;
	}
*/
	public String getSmsRemain() {
		return smsRemain;
	}

	public void setSmsRemain(String smsRemain) {
		this.smsRemain = smsRemain;
	}

	public String getKeyhash() {
		return keyhash;
	}

	public void setKeyhash(String keyhash) {
		this.keyhash = keyhash;
	}

	public boolean isMsgSwitch() {
		return msgSwitch;
	}

	public void setMsgSwitch(boolean msgSwitch) {
		this.msgSwitch = msgSwitch;
	}

	public boolean isPushSwitch() {
		return pushSwitch;
	}

	public void setPushSwitch(boolean pushSwitch) {
		this.pushSwitch = pushSwitch;
	}

	public boolean isWechatSwitch() {
		return wechatSwitch;
	}

	public void setWechatSwitch(boolean wechatSwitch) {
		this.wechatSwitch = wechatSwitch;
	}

	public boolean isEmailSwitch() {
		return emailSwitch;
	}

	public void setEmailSwitch(boolean emailSwitch) {
		this.emailSwitch = emailSwitch;
	}

	public String getPhonePush() {
		return phonePush;
	}

	public void setPhonePush(String phonePush) {
		this.phonePush = phonePush;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getNoDisturbTime() {
		return noDisturbTime;
	}

	public void setNoDisturbTime(String noDisturbTime) {
		this.noDisturbTime = noDisturbTime;
	}

	public String getRing() {
		return ring;
	}

	public void setRing(String ring) {
		this.ring = ring;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getPersonalInfo() {
		return personalInfo;
	}

	public void setPersonalInfo(String personalInfo) {
		this.personalInfo = personalInfo;
	}

	public String getFontSize() {
		return fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public String getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getLastLoginPhoneType() {
		return lastLoginPhoneType;
	}

	public void setLastLoginPhoneType(String lastLoginPhoneType) {
		this.lastLoginPhoneType = lastLoginPhoneType;
	}

	public String getLastLoginWay() {
		return lastLoginWay;
	}

	public void setLastLoginWay(String lastLoginWay) {
		this.lastLoginWay = lastLoginWay;
	}

	@Override
	public String toString() {
		return "ZYUser [userid=" + userId + ",phonenum=" + phoneNum + ",email=" + email +",switch={"+msgSwitch+":"+pushSwitch+":"+emailSwitch+":"+wechatSwitch+"}"+ ",lang="
				+  language  + ", nickname=" + nickname+",noDisturb="+noDisturbTime +",ring="+ring+",fontSize="+fontSize
			+",push="+phonePush+",channelId="+channelId+ ",headProtrait="	+ headProtrait +",info="+personalInfo+"lastLogin="+lastLoginPhoneType+":"+lastLoginWay+":"+lastLoginTime+  "]";
	}
	/**推送方式， android_0表示百度云推送，android_1表示gcm推送 */
	public enum PhonePushEnum   {
		// 利用构造函数传参
		BaiDuCloud("android_0"),GCM("android_1");

		// 定义私有变量
		private String nCode;

		// 构造函数，枚举类型只能为私有
		private PhonePushEnum(String _nCode) {
			this.nCode = _nCode;
		}

		public String getValue() {
			return (this.nCode);
		}
	}

}
