package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * 设备套餐
 * @author cxm
 *
 */
public class ChargeInfoDev implements Serializable{
	/** 设备套餐id，*/
	private String chargeId;

	/** 设备类型Id */
	private int devTypeId;

	/**套餐类型标志， 1：历史记录套餐  2：操控套餐*/
	private ChargeTypeEnum mark;

	/**套餐价格，单位：分*/
	private int price;

	/**循环存储时间，单位天。 （仅指历史记录的存储时间，与设备操控套餐无关）*/
	private int saveTime;

	/**套餐有效期限，单位天。
	 * （设备操控套餐中本字段表示设备操控期限延长的天数，历史记录套餐中本字段表示购买后套餐有效期间指定activeTime天数内本套餐内的历史记录saveTime值有效）*/
	private int activeTime;

	/**套餐折扣信息，显示给用户看*/
	private String discountInfo;

	public String getChargeId() {
		return chargeId;
	}

	public void setChargeId(String chargeId) {
		this.chargeId = chargeId;
	}

	public int getDevTypeId() {
		return devTypeId;
	}

	public void setDevTypeId(int devTypeId) {
		this.devTypeId = devTypeId;
	}

	public int getChargeMark() {
		if(mark==null){
			return -1;
		}
		return mark.getValue();
	}

	public void setChargeMark(int chargeMark) {
		if(chargeMark==ChargeTypeEnum.Operater.getValue()){
			this.mark = ChargeTypeEnum.Operater;
		}else if(chargeMark==ChargeTypeEnum.Recorder.getValue()){
			this.mark = ChargeTypeEnum.Recorder;
		}
	}
	public void setChargeMark(ChargeTypeEnum chargeMark) {
			this.mark = chargeMark ;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSaveTime() {
		return saveTime;
	}

	public void setSaveTime(int saveTime) {
		this.saveTime = saveTime;
	}

	public int getActiveTime() {
		return activeTime;
	}

	public void setActiveTime(int activeTime) {
		this.activeTime = activeTime;
	}

	public String getDiscountInfo() {
		return discountInfo;
	}

	public void setDiscountInfo(String discountInfo) {
		this.discountInfo = discountInfo;
	}

	@Override
	public String toString() {
		return "ChargeInfoDev [chargeId="
				+ chargeId + ", mark=" + mark + ", price="
				+ price + ", save_time=" + saveTime + ", activeTime="
				+ activeTime + ", discount=" + discountInfo
				+ ", devTypeId=" + devTypeId + "]";
	}


	/**
	 * 设备套餐类型
	 */
	public enum ChargeTypeEnum   {
		/**1：历史记录套餐 ，设备历史记录默认存储时长是7天，套餐内包含设备历史记录不同的存储时长*/
		Recorder(1),
		/**2：设备操控套餐，如果设备过期用户将无法控制设备，套餐内包含延长的设备操控期限 */
		Operater(2);

		// 定义私有变量
		private int nCode;

		// 构造函数，枚举类型只能为私有
		private ChargeTypeEnum(int _nCode) {
			this.nCode = _nCode;
		}

		@Override
		public String toString() {
			return String.valueOf(this.nCode);
		}

		public int getValue() {
			return (this.nCode);
		}
	}
}
