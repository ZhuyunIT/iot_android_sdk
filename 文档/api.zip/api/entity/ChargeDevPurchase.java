package com.zyiot.sdk.entity;

import java.io.Serializable;

/**
 * @author cxm
 * 已购买设备套餐信息
 */
public class ChargeDevPurchase implements Serializable{
    /**套餐类型标志， 1：历史记录套餐  2：操控套餐*/
	private ChargeInfoDev.ChargeTypeEnum chargeMark;
    /** 摄像头账号*/
    private String keyhash;
    /**购买套餐的过期时间*/
    private long expireTime;
    /**购买套餐详情，包含每一次购买的信息，json格式，如：”[ {"time":"1234567890-1345678999","charge_id":"s"},{"time":"132011000-1401810110","charge_id":"sc"}]”,time的单位是秒*/
    private String details;
    /**月推邮箱，允许额外绑定两个（用英文符号分号“;”分隔开，如“cxm@zy.com;c2@yun.com”），默认包含设备管理员邮箱（管理员邮箱一定推送）*/
    private String email;

	public int getChargeMark() {
		if(chargeMark==null){
			return -1;
		}
		return chargeMark.getValue();
	}

	public void setChargeMark(int chargeMark) {
		if(chargeMark== ChargeInfoDev.ChargeTypeEnum.Operater.getValue()){
			this.chargeMark= ChargeInfoDev.ChargeTypeEnum.Operater;
		}else if(chargeMark== ChargeInfoDev.ChargeTypeEnum.Recorder.getValue()){
			this.chargeMark= ChargeInfoDev.ChargeTypeEnum.Recorder;
		}
	}
	public void setChargeMark(ChargeInfoDev.ChargeTypeEnum chargeMark) {
		this.chargeMark = chargeMark;
	}

	public String getKeyhash() {
		return keyhash;
	}

	public void setKeyhash(String keyhash) {
		this.keyhash = keyhash;
	}

	public long getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(long expireTime) {
		this.expireTime = expireTime;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "ChargeDevPurchase [mark="
				+ chargeMark + ", keyhash=" + keyhash + ", expireTime="
				+ expireTime + ", details=" + details + ", email=" + email
				+ "]";
	}

}
