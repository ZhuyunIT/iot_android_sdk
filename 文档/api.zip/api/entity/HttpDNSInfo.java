package com.zyiot.sdk.entity;

import org.json.JSONArray;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * 服务器DNS信息：包含TenantId、ZOT模块IP和域名地址、IOT(XOT)地址、服务器名称等
 * @author cxm
 *
 */
public class HttpDNSInfo implements Serializable{
    /**APP版本（APP可以根据自己的版本选择可使用的服务器）*/
	private String version;

	/**单位：秒，HttpDNS信息的有效时间。建议获取DNS信息过了指定秒数时间后重新获取新的DNS信息*/
    private long refreshTime  ;

    /**DNS信息，包含支持的服务器地址信息及其Tenant账号*/
	private List<ServerInfo> servers;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public long getRefreshTime() {
        return refreshTime;
    }

    public void setRefreshTime(long refreshTime) {
        this.refreshTime = refreshTime;
    }

    public List<ServerInfo> getServers() {
        return servers;
    }

    public void setServers(List servers) {
        this.servers = servers;
    }

    @Override
	public String toString() {
		return "DNSInfo[v="
				+ version +  ", servers="
				+ servers +  ", refreshTime=" + refreshTime + "]";
	}

	//服务器的信息
	public class ServerInfo{
        /**标识这个服务器DNS信息*/
        private int Id;
        /**APP支持的TennatId*/
        private int tenantId;
        /**ZOT所在服务器的域名*/
        private String zotDomain;
        /**ZOT所在服务器的IP*/
        private String zotIp;
        /**XOT（IOT）程序所在服务器的域名或IP列表，形如“地址;地址;地址”*/
        private String xot;
        /**服务器名称 ：键是语言，值是对应语言的服务器名称，如en:china,zh:中国大陆*/
        private HashMap<String,String> serverNames;

        public int getId() {
            return Id;
        }



        public void setId(int id) {
            Id = id;
        }

        public int getTenantId() {
            return tenantId;
        }

        public void setTenantId(int tenantId) {
            this.tenantId = tenantId;
        }

        public String getZotDomain() {
            return zotDomain;
        }

        public void setZotDomain(String zotDomain) {
            this.zotDomain = zotDomain;
        }

        public String getZotIp() {
            return zotIp;
        }

        public void setZotIp(String zotIp) {
            this.zotIp = zotIp;
        }

        public String getXot() {
            return xot;
        }

        public void setXot(String xot) {
            this.xot = xot;
        }

        public HashMap<String, String> getServerNames() {
            return serverNames;
        }

        public void setServerNames(HashMap<String, String> serverNames) {
            this.serverNames = serverNames;
        }
        public void setServerName(String language,String serverName) {
            if(this.serverNames==null){
                this.serverNames=new HashMap<>();
            }
            if(language!=null){
                this.serverNames.put(language,serverName);
            }
        }

        /***
         * 根据APP语言获取服务器名称
         * @param language  APP语言
         * @return
         */
        public String getServerName(String language ) {
            if(this.serverNames!=null&&language!=null&&this.serverNames.containsKey(language)){
               return this.serverNames.get(language);
            }
            return "";
        }

        @Override
        public String toString() {
            return "Server[id="+Id+",tenantId="+tenantId+",zotDomain="+zotDomain+",zotIp="+zotIp+",xot="+xot+",serverName="+serverNames+"]";
        }
    }
}
