package com.zyiot.sdk.entity;

import android.text.TextUtils;

import org.json.JSONObject;

import java.io.Serializable;
import java.util.HashMap;

/**
 * @author cxm
 */
public class DeviceInfoEntity implements Serializable {

    /**设备Keyhash */
    private String keyhash;

    /**设备类型Id，可在设备二维码上找到 */
    private int devTypeId;

    /**设备权限，level=0是管理员，操控设备无时间限制；2是二级用户，操控设备的时间权限由管理员决定*/
    private int level;

    /**微信公众号推送开关（单个设备暂不开放设置） */
    private boolean wechatSwitch;

    /**邮箱推送开关（单个设备暂不开放设置） */
    private boolean emailSwitch;

    /**手机APP推送开关（单个设备暂不开放设置） */
    private boolean pushSwitch;

    /**用户权限，二级用户时此值有效 */
    private AuthorityEntity authority;

    private HashMap<String, DeviceAttr> attrs = new HashMap<String, DeviceAttr>();

    public DeviceInfoEntity() {
        // TODO Auto-generated constructor stub
    }


    public String getKeyhash() {
        return keyhash;
    }

    public void setKeyhash(String keyhash) {
        this.keyhash = keyhash;
    }

    public int getDevTypeId() {
        return devTypeId;
    }

    public void setDevTypeId(int devTypeId) {
        this.devTypeId = devTypeId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public boolean isWechatSwitch() {
        return wechatSwitch;
    }

    public void setWechatSwitch(boolean wechatSwitch) {
        this.wechatSwitch = wechatSwitch;
    }

    public boolean isPushSwitch() {
        return pushSwitch;
    }

    public void setPushSwitch(boolean pushSwitch) {
        this.pushSwitch = pushSwitch;
    }


    public HashMap<String, DeviceAttr> getAttrs() {
        return attrs;
    }

    /**获取指定的属性值*/
    public DeviceAttr getOneAttr(String attrName) {
        if (attrName != null && attrs.containsKey(attrName)) {
            return attrs.get(attrName);
        }
        return null;
    }

    /**获取指定的属性值*/
    public String getOneAttrValue(String attrName) {
        if (attrName != null && attrs.containsKey(attrName)) {
            DeviceAttr attr = attrs.get(attrName);
            if (attr != null) {
                return attr.getValue();
            }
        }
        return null;
    }

    /**
     * 解析在线/离线属性：online@zot
     *
     * @return
     */
    public boolean getOnline() {
        boolean online = false;
        if (attrs != null && attrs.containsKey("online@zot") && !TextUtils.isEmpty(attrs.get("online@zot").getValue())) {
            String value = attrs.get("online@zot").getValue();
            if ("1".equals(value) || "true".equals(value)) {
                online = true;
            } else {
                online = false;
            }
        }
        return online;
    }

/**获取设备名称，当没有名称时使用keyhash*/
    public String getDevNameAttrValue() {
        DeviceInfoEntity device = this;
        String name = device.getKeyhash();
        if (name == null) {
            name = "";
        }
        if (device.getAttrs().containsKey("devname@zot")) {
            DeviceAttr attr = device.getAttrs().get("devname@zot");
            if (!TextUtils.isEmpty(attr.getValue())) {
                name = attr.getValue();
            }
        }
        return name;
    }

    public void setDevNameAttrValue(String devName) {
        DeviceInfoEntity device = this;
        if (device.getAttrs().containsKey("devname@zot")) {
            HashMap<String, DeviceAttr> map = device.getAttrs();
            if (map.containsKey("devname@zot") && map.get("devname@zot") != null) {
                map.get("devname@zot").setValue(devName);
            }
        }
    }

    /**
     * 摄像头信息是以json形式保存的字符串
     *
     * @return
     */
    public JSONObject getDevCameraInfoAttrJsonValue() {
        JSONObject jsonObject = null;
        if (getAttrs().containsKey("camera@zot")) {
            DeviceAttr attr = getAttrs().get("camera@zot");
            String va = attr.getValue();
            if (!TextUtils.isEmpty(va)) {
                try {
                    jsonObject = new JSONObject(va);
                } catch (Exception e) {
                }
            }
        }
        return jsonObject;
    }

    /*获取设备绑定的摄像头信息，返回为空时表示没有绑定摄像头camera；否则表示有绑定摄像头
     * 有绑定摄像头时返回的内容：cameraId，pwd，originalPwd，accessToken
     * */
    public DeviceCameraInfo getDevCameraInfo() {
        DeviceInfoEntity device = this;
       DeviceCameraInfo info = null;
        if (device.getAttrs().containsKey("camera@zot")) {
            DeviceAttr attr = device.getAttrs().get("camera@zot");
            String va = attr.getValue();
            if (TextUtils.isEmpty(va)) {
                return info;
            }
                try {
                    JSONObject job = new JSONObject(va);
                    String noId = job.optString("cameraId");
                    String pwd = job.optString("password");
                    String pwdOld = job.optString("originalPassword");
                    String accessToken = job.optString("accessToken");
                    if (TextUtils.isEmpty(noId) || "null".equals(noId) || noId.trim().length() == 0) {
                        return info;
                    }
                    info=new DeviceCameraInfo();
                    info.setCameraId(noId);
                    info.setPassword(pwd);
                    info.setOriginalPassword(pwdOld);
                    info.setAccessToken(accessToken);
                } catch (Exception e) {

                }
        }
        return info;
    }


    public void setAttrs(HashMap<String, DeviceAttr> attrs) {
        if (attrs != null) {
            this.attrs.putAll(attrs);
        }
    }

    public void clearAttrs() {
        this.attrs.clear();
    }


    public boolean isEmailSwitch() {
        return emailSwitch;
    }

    public void setEmailSwitch(boolean emailSwitch) {
        this.emailSwitch = emailSwitch;
    }


    public AuthorityEntity getAuthority() {
        return authority;
    }

    public void setAuthority(AuthorityEntity authority) {
        this.authority = authority;
    }

    public void setAuthority(String authority) {
            this.authority=AuthorityEntity.initAuthorityJSON(authority);
    }

    @Override
    public String toString() {
        return "Device [keyhash=" + keyhash + ", level=" + level + ",attrs=" + attrs
                +" auth="+authority+ "]";
    }


}
