package com.zyiot.sdk;

public class ZYFotaAPI {

    /**
     * 获取接口实例
     */
    public static ZYFotaAPI getInstance() ;



    /**
     * 设置Fota模块的域名或IP，只能一个IP或域名
     */
    public void setFotaDomain(String domain);

    /**
     * 设置Fota模块的端口号
     */
    public void setFotaPort(final int port) ;

    /**
     * 连接服务器
     */
    public void openConnection() ;

    /**
     * 停止连接
     */
    public void shutdown() ;


    /**
     * 实现接口可以得到检测版本结果和升级进度
     *
     * @param listener 回调接口
     */
    public void setDevUpdateListener(ZYDevUpdateListener listener) ;

    /***
    @param keyhash 指定检测的设备
    @param listener 结果回调
    */
    public void setDevUpdateInfo(String keyhash, ZYDevUpdateListener listener) ;

    /**
     * 检测设备是否需要升级
     */
    public void checkDevUpdateVersion();

    /**
     * 获取设备升级的进度
     */
    public void getDevUpdateProgress();

    /**
     * 发送event通知设备升级
     *
     * @return 返回eventId数值则表示已发送，具体发送Event的结果请实现ZYEventResponseDelegate代理监听
     */
    public String setDevUpdateStart() ;

}
