package com.zyiot.sdk;

import android.content.Context;

import com.zyiot.sdk.dao.ZYListener;
import com.zyiot.sdk.entity.AuthorityEntity;

public  class ZYOpenAccount extends ZYBaseSDK {

    public static ZYOpenAccountSDK getZYOpenAccountSDKInstance(Context context);

    /**
     * 初始化SDK
     *
     * @param tenantId  ZY提供的TenantID
     * @param appId     ZY提供的APP ID
     * @param appSecret ZY提供的APP Secret
     * @param appToken  第三方用户登录自有用户系统的token
     * @param server    服务器IP或域名
     * @param listener  回调
     * @return ZYOpenAccountSDK 实例
     */
    public static ZYOpenAccountSDK initZYOpenAccountSDK(Context context, int tenantId, String appId, String appSecret, String appToken, String server, ZYListener.getUserToken listener);

    /**
     * 初始化SDK
     *
     * @param tenantId  ZY提供的TenantID
     * @param appId     ZY提供的APP ID
     * @param appSecret ZY提供的APP Secret
     * @param appToken  第三方用户登录自有用户系统的token
     * @param listener  回调
     * @return ZYOpenAccountSDK 实例
     */
    public static ZYOpenAccountSDK initZYOpenAccountSDK(Context context, int tenantId, String appId, String appSecret, String appToken, ZYListener.getUserToken listener);

    /**
     * set UserInfo
     * 参数：
     * 可选参数：(传入要设置的值，其余值置空即可)
     * msgSwitch：消息推送开关
     * pushSwitch：推送总开关
     * emailSwitch：邮箱推送总开关
     * wechatSwitch：微信推送总开关
     * phonePush：手机推送
     * channelId：推送通道id
     * noDisturbTime：消息免打扰时间（以秒为单位，中间用‘-’隔开，如：12345-34567；如果结束时间小于起始时间，说明是第二天）
     * headProtrait：头像路径
     * ring：个性铃声
     * language：语言（zh中文，en英文）
     * fontSize：字体大小
     * personalInfo：个人信息
     * 注：不需要用户昵称，用户昵称登录时由第三方后台提供。
     * listener: callback
     */
    void openSetUserInfo(String msgSwitch, String pushSwitch, String emailSwitch, String wechatSwitch
            , String phonePush, String channelId, String noDisturbTime, String headProtrait
            , String ring, String language, int fontSize, String personalInfo, ZYListener listener);


    /**
     * 获取用户信息
     * 返回的User信息userId字段指的是第三方用户Id，不是zotUserId。
     */
    void openGetUserInfo(ZYListener.getUserInfo listener);


    /**
     * 解除微信公众号绑定(会收不到微信推送)
     *
     * @param listener callback(retcode,errText)
     */
    void openWechatRemovePublic(ZYListener listener);


    /**
     * 一级用户授权给二级用户
     * 参数：
     * keyhash device
     * authUserId：被授权用户Id，为第三方系统的用户Id。
     * authority：用户控制权限，json数据。
     * remark：备注
     * 注：1.  未购买历史记录套餐，二级授权最高5个，购买历史记录套餐，最高19个。
     * 授权二级用户需要推送和存储log记录。
     * authority: json格式数据，type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳，中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。shareTime表示分享时间，为时间戳。
     * listener: callback
     */
    void openAuthorizeUser(String keyhash, String authUserId, String authority, String remark, ZYListener listener);

    void openAuthorizeUserForEntity(String keyhash, String authUserId, AuthorityEntity authority, String remark, ZYListener listener);


    /**
     * 一级用户修改二级用户权限
     * 参数：
     * keyhash
     * authUserId：授权用户Id，为第三方userId
     * authority：用户控制权限，json数据。
     * remark：备注
     * listener :callback
     */
    void openModifyAuthUser(String keyhash, String authUserId, String authority, String remark,
                            ZYListener listener);

    void openModifyAuthUserForEntity(String keyhash, String authUserId, AuthorityEntity authority, String remark, ZYListener listener);


    /**
     * 一级用户解授权二级用户
     * 参数：
     * keyhash device
     * authUserId：授权用户Id，为第三方userId
     */
    void openUnAuthorizeUser(String keyhash, String authUserId, ZYListener listener);


    /**
     * 获取设备所属的用户列表（包括管理员、二级用户、临时用户）
     *
     * @param keyhash  device
     * @param listener callback list:ZYUser list:ZYTempUser
     */
    void openGetUserList(String keyhash, ZYListener.getUserList listener);


     /*** 
     转移设备管理员权限给指定用户
     注：1.管理员才可以转移设备，转移设备后该用户失去管理员权限，设备下的所有二级用户、临时用户均被删除，设备新管理员是指定的用户。
     * @param password 转移设备管理员权限需要用户登录密码
     * @param keyhash 设备
     * @param authUserId 转移给指定用户（为第三方用户userId）
     * @param listener
     */
    void openMoveDevToUser( String password,  String keyhash,  String authUserId,  ZYListener listener);



}
