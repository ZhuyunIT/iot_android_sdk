package com.zyiot.sdk.dao;

/**
 * SDK状态回调接口
 */
public interface ZYSDKLoginStateListener {
void sdkLoginSuccess();//SDK init 成功
void sdkLoginFailure(int retcode, String errDescription);//SDK init 失败（SDK内有些API无法正常使用）

}
