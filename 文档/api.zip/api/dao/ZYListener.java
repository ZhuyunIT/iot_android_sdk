package com.zyiot.sdk.dao;

import com.zyiot.sdk.entity.*;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@android.support.annotation.Keep
public interface ZYListener {
    void callBackRetcode(int retcode,String errDescription);

    public interface getStringInfo {
        void callBackString(String info,int retcode,String errDescription);
    }

    public interface getVerifyCodeResult{
        /**
         * @param isPhone 验证码发送方式 ,true表示手机短信接收验证码，否则是邮箱接收。
         * @param smsRemain 剩余短信条数（如果是用手机号发送验证码）
         * @param account 验证码发送到该账号
         * @param retcode 200成功，其它失败
         * @param errDescription
         */
        void callBackVerify(boolean isPhone,int smsRemain,String account,int retcode,String errDescription);
    }
    public interface getModifyAccountVerifyResult{
        /**
         * @param isPhone 验证码发送方式 ,true表示手机短信接收验证码，否则是邮箱接收。
         * @param smsRemain 剩余短信条数（如果是用手机号发送验证码）
         * @param retcode 200成功，其它失败
         * @param errDescription
         */
        void callBackVerify(boolean isPhone,int smsRemain,int retcode,String errDescription);
    }
    public interface getThirdBindVerifyResult{
        /**
         * @param isSendVerifyCodeSuccess 是否已发送验证码，true表示已发送验证码(账号未注册)，false表示未发送。
         * @param userId 不为空则表示账号已注册，且用户密码正确，校验通过，微信授权登录绑定筑云账号成功
         * @param retcode 200成功，其它失败
         * @param errDescription
         */
        void callBackVerify(boolean isSendVerifyCodeSuccess, String userId,int retcode,String errDescription);
    }
    public interface getUserToken {
        void callBackUserToken(ZYUserToken userToken,int retcode,String errDescription);
    }
    public interface getUserTokenWechat {
        void callBackUserTokenWechat(ZYUserTokenWechat userTokenWechat,int retcode,String errDescription);
    }
    public interface getUserTokenFacebook {
        void callBackUserTokenFacebook(ZYUserTokenFacebook userTokenFacebook,int retcode,String errDescription);
    }
    public interface getUserInfo  {
        void callBackUserInfo(ZYUser user,int retcode,String errDescription);
    }
    public interface getUserList  {
        void callBackUserList(List<ZYAuthUser> authUsers,List<ZYTempUser> tempUsers,int retcode,String errDescription);
    }
    public interface authToUser {
        void callBackAuthUser( ZYAuthUser authUser ,int retcode,String errDescription);
    }
    public interface getDevInfo{
        void callBackDevInfo(DeviceInfoEntity dev,int retcode,String errDescription);
    }
    public  interface getDevList {
        void callBackDevList(List<DeviceInfoEntity> devs, int retcode, String errDescription);
    }
    public  interface getDevLogList {
        void callBackDevLogList(List<DeviceLogEntity> logs, int retcode, String errDescription);
    }

    public interface getSceneInfo{
        void callBackSceneInfo( DeviceSceneInfo scene, int retcode,String errDescription);
    }
    public interface getSceneList{
        void callBackSceneList( List<DeviceSceneInfo> scenes, int retcode,String errDescription);
    }
    public interface getLinkageList{
        void callBackLinkageList( List<DeviceLinkage> linkages, int retcode,String errDescription);
    }
    public interface getTimedTaskList{
        void callBackTimedTaskList( List<DeviceTimedTask> timedTasks, int retcode,String errDescription);
    }
    public interface getAttrOperationList{
        void callBackAttrOperationList( List<DevAttrOperation> attrOperas, int retcode,String errDescription);
    }

    public interface getTrigger{
        void callBackTrigger(DevTrigger trigger, int retcode,String errDescription);
    }
    public interface getTriggerSwitch{
        void callBackTriggerSwitch(String triggerId ,boolean triggerSwitch, int retcode,String errDescription);
    }

    public interface getTriggerList{
        void callBackTriggerList(List<DevTrigger> triggers,int retcode,String errDescription);
    }
    public interface getCustomerTriggerList{
        void callBackCustomerTriggerList(List<DevCustomerTrigger> triggers,int retcode,String errDescription);
    }

    public interface getChargeInfoList{
        void callBackChargeInfoList(List<ChargeInfo> infos,int retcode,String errDescription);
    }
    public interface getChargeInfoSMSList{
        void callBackChargeInfoSMSList(List<ChargeInfoSMS> infos,int retcode,String errDescription);
    }
    public interface getPayedChargeInfoMap{
        void callBackPayChargeInfos(Map<String,ChargePurchase> infoMap, int retcode, String errDescription);
    }
    public interface getPriceForChargeInfo{
        void callBackPriceInfo( ChargeInfo info,int retcode,String errDescription);
    }
    public interface getPriceForChargeInfoSMS{
        void callBackPriceInfoSMS( ChargeInfoSMS info,int retcode,String errDescription);
    }


    public interface orderToBuyCharge {
//        void callBackOrder( boolean orderSuccess, String prePayId, String nonceStr, String timestamp, String sign,int retcode,String errDescription);
        void callBackOrder(boolean orderSuccess,ChargeOrderInfo info, int retcode, String errDescription);
    }

    public interface getMsgTypeList{
        void callBackMsgTypeList(List<MessageType> infos,int retcode,String errDescription);
    }
    public interface getMsgList{
        void callBackMsgList(List<MessageCenterMsg> infos,List<MessageCenterMsgDelete> deleteCacheInfos,int retcode,String errDescription);
    }
    public interface getHttpDNSInfoList{
        void callBackDNSInfoList(List<HTTPDNSInfo> infos,int retcode,String errDescription);
    }
}
