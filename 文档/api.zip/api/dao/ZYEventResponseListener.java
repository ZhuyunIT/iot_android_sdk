package com.zyiot.sdk.dao;

public interface ZYEventResponseListener {
    /**
     * Event接收：APP发送Event、服务器/其他设备发给APP的Event。平台主动下发Event时source为null。
     */
    void onEventForAPP(com.zyiot.common.endpoint.gen.ZyEventData eventData, String source, boolean isRead, boolean readState);

    /**
     * Event接收：子设备发送Event、服务器/其他设备发给子设备的Event。平台主动下发Event时source为null。
     */
    void onEventForChildDev(com.zyiot.common.endpoint.gen.ZyEventData eventData, String source, String childDevKeyhash, boolean isRead, boolean readState);

    /**
     * @param isSuccess    true：成功，false：失败
     * @param isLogin      true：登录，false：退出
     * @param devType      子设备类型：如蓝牙为bluetooth
     * @param childKeyhash
     */
    void onEventForChildDevLoginOrOut(boolean isSuccess, boolean isLogin, String devType, String childKeyhash);

    /**
     * sync Response : 发送Event到服务器是否成功的回复
     */
    void onEventSyncResponseWithStatus(boolean isSuccess, int eventId);

    //Event Received with status=ERROR
    public void onEventFailureWithEventId(int eventId);
}

