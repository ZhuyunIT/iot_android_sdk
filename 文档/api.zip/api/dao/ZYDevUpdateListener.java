package com.zyiot.sdk.dao;

public interface ZYDevUpdateListener {

/**
 @param retcode 1-ok, 0-exp(keyhash not found)
 @param isNewest true-isNewest, false-need to update
 @param isForceUpdate true-need update(不升级无法正常使用),false-不是强制升级
 @param currentV 设备当前版本
 @param newestV 设备最新版本
 */
void callCheckDevUpdate(int retcode, String keyhash, boolean isNewest, boolean isForceUpdate, String currentV, String newestV);

/**get device update progress
 @param keyhash device
 @param progress  update progress
 */
void callGetDevUpdateProgress(int retcode, String keyhash, int progress);


void onCloseConnectToFota();
}
