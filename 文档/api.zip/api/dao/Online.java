package com.zyiot.zy.status;

/**
 * 用于监听APP的离线和上线的
 *
 * @author zhouyinfei
 */
public class Online {

    public Online();

    public void onGenericConnect();

    public void onGenericDisConnect();

    public boolean addListener(IOTOnlineListener listener);

    public boolean removeListener(IOTOnlineListener listener);

    public interface IOTOnlineListener {
        void onIOTConnect();//连接成功的回调

        void onIOTDisConnect();//连接断开的回调
    }
}
