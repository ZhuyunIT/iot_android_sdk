package com.zyiot.sdk;

import com.zyiot.client.ZYIOTClientStateListener;
import com.zyiot.sdk.dao.ZYListener;
import com.zyiot.zy.event.ZYEventResponseListener;
import com.zyiot.zy.status.Online;

public abstract class ZYBaseSDK  extends ZYBaseAPI{

    /**
     * 获取连接筑云ZOT服务器URL
     */
    public  String getZotUrlBaseStr();

    /***
     * 获取筑云DNS服务器URL
     */
    public String getDNSUrlBaseStr() 

    /**
     * @param tenantId 筑云提供的一个服务器账号数字标识
     */
    public void setTenantId(int tenantId);

    /**
     * ZOT服务器， 只能一个域名或IP
     *
     * @param domain 修改API连接的服务器域名或IP
     */
    public void setZotDomain(String domain);

    /**
     * @param port 修改API连接服务器时使用的http端口号
     */
    public void setZotPort(int port);

    /**
     * 获取DNSKey 
     * DNSKey是访问DNS服务器的身份令牌，是由筑云分配给APP开发者的，请提前申请
     * @return  DNSKey
     */
    public String getDNSKey() ;

    /**
     * 设置DNSKey 
     * DNSKey标识了本APP对应服务器DNS信息，获取DNS信息前需要先设置DNSKey值
     * @param dnsKey DNSKey
     */
    public void setDNSKey(String dnsKey);
    
    /**
     * 设置DNS服务器域名或IP地址（只能设置一个域名或IP）
     * @param domain
     */
    public void setHttpDNSServerDomain(String domain);


    /**
     * 获取zotToken
     *
     * @return zot token
     */
    public String getZotToken();

    /**
     * 设置zotToken
     *（请不要随意设置本值，若设置的Token无效，会影响SDK的使用）
     * @param zotToken zot token
     */
    public void setZotToken(String zotToken);

    /**
     * 获取zotRefreshToken
     *
     * @return zot refreshToken
     */
    public String getZotRefreshToken();

    /**
     * 设置zotRefreshToken
     *
     * @param zotRefreshToken zot refreshToken
     */
    public void setZotRefreshToken(String zotRefreshToken);



    /**
     * 获取属性值（全部属性）
     *
     * @param keyhash  keyhash
     * @param listener callback(DeviceInfoEntity *dev,int retcode ,NSString *errDescription)
     */
    void getDevAttrList(String keyhash, ZYListener.getDevInfo listener);


    /**
     * 获取属性值列表（不包含全局属性）
     *
     * @param keyhash  keyhash
     * @param listener callback(DeviceInfoEntity  dev,int retcode , String  errDescription)
     */
    void getDevAttrListForNoGlobal(String keyhash, ZYListener.getDevInfo listener);


    /**
     * 设置属性
     *（发送控制设备的属性不建议使用本API，请使用IOTClient的sendEvent接口，反应速度更快）
     * @param keyhash  device
     * @param name     attrNames (多个属性时用英文符号“;”分号分隔，分隔后的属性名数量与属性值分隔后的属性值数量要一致)
     * @param value    attrValues（多个属性时用英文符号“;”分隔）
     * @param listener callback
     */
    void setDevAttrs(String keyhash, String name, String value, ZYListener listener);


      /***
     * 设备绑定摄像头、为摄像头更换摄像头信息
     * 注：设备只绑定一个摄像头
     * @param keyhash
     * @param cameraInfo 萤石摄像头信息（accessToken、cameraId、默认密码(验证码)、摄像头当前密码），请确保accessToken对应的萤石用户对这个cameraId的摄像头有操作权限。
     * @param listener callback(int retcode ,String errDescription)
     */
    void devBindCamera(String keyhash, DeviceCameraInfo cameraInfo, ZYListener listener);

    /***
     * 设备删除绑定的摄像头
     * @param keyhash
     * @param listener callback(int retcode ,String errDescription)
     */
    void devDeleteCamera(String keyhash, ZYListener listener);


    /**
     * 设备重置，同时将清除所有与用户的绑定关系
     *
     * @param keyhash  device
     * @param listener callback
     */
    void devResetDev(String keyhash, ZYListener listener);


    /**
     * 获取历史记录
     * 参数：
     *
     * @param keyhash
     * @param timestamp1：起始时间戳，以秒为单位
     * @param timestamp2：结束时间戳，以秒为单位
     * @param limit：log返回条数限制，如果limit=0，不做限制 注：1.如果timestamp1和timestamp2都为0，说明查找所有数据；如果timestamp1>=0，timestamp2>0，说明查找timestamp1和timestamp2之间的数据;要求timestamp1和timestamp2都大等于0，且timestamp1<=timestamp2;
     *                                       2.获取的历史记录是与自己相关的历史记录，不是所有用户的历史记录，这与zot2.0不同。
     * @param listener:callback              list:DeviceLogEntity
     */
    void getDevLogs(String keyhash, long timestamp1, long timestamp2, int limit, ZYListener.getDevLogList listener);


    /**
     * 绑定设备
     *
     * @param keyhash   设备ID，在设备二维码上可见
     * @param devTypeId 指定设备类型，在设备二维码上可见
     * @param listener  callback
     */
    void bindDev(String keyhash, String devTypeId, ZYListener listener);

    /**
     * 删除设备。若是管理员删除设备，设备的二级用户都将同步删除。
     *
     * @param keyhash  device
     * @param listener callback
     */
    void deleteDevice(String keyhash, ZYListener listener);




    /**
     * 获取用户下的设备列表（不含属性值）
     *
     * @param listener callback list:DeviceInfoEntity
     */
    void getDevList(ZYListener.getDevList listener);


    /**
     * 获取用户下带部分属性的设备列表
     * 设备包含的属性值有：camera@zot、online@zot、devname@zot、dev_head_protrait@zot、expire_time@zot。分别表示绑定的摄像头信息、在线状态、设备名称、设备头像图片名、设备过期时间。
     *
     * @param listener callback list:DeviceInfoEntity
     */
    void getDevListWithSomeAttrs(ZYListener.getDevList listener);
    
    /**
     * 增加临时用户分享
     * 参数：
     * keyhash：设备标识
     * authority：临时分享权限，格式见AuthorityTempEntity.java文件
     * remark：备注
     * 注：临时用户不能登录平台，但是可以访问指定网页进行设备控制，如有需要请咨询筑云技术支持
     * @param listener callback(tempShareId, retcode ,errDescription)
     */
    void shareTempUser( String keyhash,  AuthorityTempEntity authority,  String remark,  ZYListener.getStringInfo listener) ;
    
    /**
     * 编辑临时用户权限
     * 参数:
     * tempShareId：临时分享Id
     * authority：临时分享权限，格式见AuthorityTempEntity.java文件
     * remark：备注
     * listener: callback
     */
    void modifyTempUser( String tempShareId,  AuthorityTempEntity authority,  String remark,  ZYListener listener) ;
      

    /**
     * 删除临时用户
     * 参数：
     *
     * @param tempShareId：临时分享Id
     */
    void deleteTempUser(String tempShareId, ZYListener listener);

    /**
     * 设置设备推送开关
     * 参数：
     *
     * @param keyhash             可选参数：(只传入有效值，不设置则置空)
     * @param pushSwitch：推送开关
     * @param emailSwitch：邮箱推送开关
     * @param wechatSwitch：微信推送开关
     */
    void setDevPushSwitch(String keyhash, String pushSwitch, String emailSwitch, String wechatSwitch, ZYListener listener);

    /**
     * 获取设备触发器列表
     *
     * @param listener callback list:DeviceTrigger
     *                 注：设备触发器的创建、修改、删除都需要厂家权限，普通用户不能操作。普通用户只能查看触发器列表。
     */
    void getDevTriggerList(ZYListener.getTriggerList listener);

    /**
     * 获取设备触发器开关
     *
     * @param keyhash   device
     * @param triggerId 触发器Id
     * @param listener  callback(triggerId,switchBoo,retcode,err)
     */
    void getDevTriggerSwitch(String keyhash, String triggerId, ZYListener.getTriggerSwitch listener);

    /**
     * 设置触发器开关
     *
     * @param keyhash       device id
     * @param triggerId     trigger id
     * @param triggerSwitch 触发器开关  true为开，false为关
     * @param listener      callback
     */
    void setDevTriggerSwitch(String keyhash, String triggerId, boolean triggerSwitch, ZYListener listener);

    /**
     * 获取设备自定义触发器列表
     *
     * @param keyhash  device id
     * @param listener callback list:DeviceCustomerTrigger
     */
    void getDevCustomTriggerList(String keyhash, ZYListener.getCustomerTriggerList listener);


    /**
     * 用户增加一个设备自定义触发器
     *
     * @param keyhash   device id
     * @param attrName  attrName
     * @param condition attrvalue的触发条件，json格式数据，包含operation，threshold。
     *                  operation：触发条件，包括：>，<，>=，<=，==，!=，contains，equals。threshold：阈值。
     * @param timeLimit 时间限制，json格式数据：
     *                  type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。
     *                  形如：{"type":"2","time":"12345-23456","week":"127"}
     * @param status    触发状态，是否可触发，true是，false否
     * @param remark    备注
     * @param listener  callback(triggerId, retcode, errDescription)
     */
    void addDevCustomTrigger(String keyhash, String attrName, String condition, String timeLimit, boolean status, String remark, ZYListener.getStringInfo listener);

    /**
     * 修改一个自定义触发器
     *
     * @param triggerId triggerId
     * @param keyhash   device id
     * @param attrName  attr name
     * @param condition attrvalue的触发条件 ,JSON格式
     * @param timeLimit 时间限制,json格式
     * @param status    触发状态，是否可触发，true是，false否
     * @param remark    备注
     * @param listener  callback
     */
    void modifyDevCustomTrigger(String triggerId, String keyhash, String attrName, String condition, String timeLimit, boolean status, String remark, ZYListener listener);

    /**
     * 删除一个自定义触发器
     *
     * @param triggerId trigger id
     * @param listener  callback
     */
    void deleteDevCustomTrigger(String triggerId, ZYListener listener);

    /**
     * 获取场景列表
     *
     * @param listener callback list:DeviceSceneInfo
     */
    void getSceneList(ZYListener.getSceneList listener);

    /**
     * 增加一个场景
     *
     * @param sceneName scene name
     * @param sceneType 场景类型  0：定时任务  1：设备联动。注：场景类型创建后不能修改
     * @param remark    备注
     * @param listener  callback(sceneId,retcode,errDescription)
     */
    void addScene(String sceneName, String sceneType, String remark, ZYListener.getStringInfo listener);
    /**
     * 增加一个场景
     *
     * @param sceneName scene name
     * @param sceneType 场景类型  0：定时任务  1：设备联动。注：场景类型创建后不能修改
     * @param remark    备注
     * @param listener  callback(sceneId,retcode,errDescription)
     */
    void addScene(String sceneName,   ZYSceneType sceneType,   String remark,   ZYListener.getStringInfo listener) {
     
    /**
     * 修改一个场景
     *
     * @param sceneId   scenen id
     * @param sceneName scenne name
     * @param remark    备注
     * @param listener  callback
     */
    void modifyScene(String sceneId, String sceneName, String remark, ZYListener listener);

    /**
     * 删除一个场景。注：会将场景相关定时任务或设备联动都删除
     *
     * @param sceneId  scenen id.场景Id
     * @param listener callback
     */
    void deleteScene(String sceneId, ZYListener listener);

    /**
     * 获取单个场景的详细信息，含任务列表：定时任务列表或联动任务列表
     *
     * @param sceneId  scenen id
     * @param listener callback
     */
    void getSceneInfo(String sceneId, ZYListener.getSceneInfo listener);

    /**
     * 获取设备下的定时任务列表
     *
     * @param keyhash  device
     * @param listener callback list:DeviceTimedTask
     */
    void getDevTimedTaskList(String keyhash, ZYListener.getTimedTaskList listener);


    /**
     * 增加一条定时任务
     * 定时任务时间有两种，一种是定期单次任务，一种是周重复任务。定期单次任务是指定具体时间，为年月日时分的时间戳，周重复任务是指定周几的几时几分。最小精确到分钟。
     *
     * @param keyhash   device
     * @param time      任务触发时间，如果是定期单次，如北京时间2017/11/7 10:26:00，存储为1510021560。如果是周重复任务，time为小时分钟转换成秒数，小时分钟随系统时间。
     * @param attrName  属性名
     * @param attrValue 属性值
     * @param repeat    任务重复，如果是定期单次任务，repeat为空。如果是周重复任务，repeat才有效。repeat值为1,2,3,4,5,6,7，分别代表周一到周日,多天时需要用英文符逗号分隔开。如值为1,3,6表示周一周三周六。
     * @param remark    备注
     * @param sceneId   加入指定场景，不加入到场景则此值可为空
     * @param listener  callback(timedTaskId,retcode,errDescription)
     */
    void addDevTimedTask(String keyhash, long time, String attrName, String attrValue, String repeat, String remark, String sceneId, ZYListener.getStringInfo listener);

    /**
     * 修改一条定时任务
     *
     * @param timedTaskId timedTaskId
     * @param keyhash     device
     * @param time        任务触发时间，如果是定期单次，如北京时间2017/11/7 10:26:00，存储为1510021560。如果是周重复任务，time为小时分钟转换成秒数，小时分钟随系统时间。
     * @param attrName    属性名
     * @param attrValue   属性值
     * @param repeat      任务重复，如果是定期单次任务，repeat为空。
     *                    如果是周重复任务，repeat才有效。repeat值为1,2,3,4,5,6,7，分别代表周一到周日,多天时需要用英文符逗号分隔开。如值为1,3,6表示周一周三周六。
     * @param remark      备注
     * @param sceneId     加入指定场景，不加入到场景则此值可为空
     * @param listener    callback
     */
    void modifyDevTimedTask(String timedTaskId, String keyhash, long time, String attrName, String attrValue, String repeat, String remark, String sceneId, ZYListener listener);

    /**
     * 删除一条定时任务
     *
     * @param timedTaskId timedTask Id
     * @param listener    callback
     */
    void deleteDevTimedTask(String timedTaskId, ZYListener listener);

    /**
     * 获取该用户下的设备联动任务列表
     *
     * @param listener callback list:DeviceLinkage
     */
    void getDevLinkageList(ZYListener.getLinkageList listener);

    /**
     * 增加一条设备联动
     *
     * @param keyhash    联动设备1（主动联动设备，触发设备）
     * @param attrName   联动设备1的属性名
     * @param condition  设备联动条件，json格式，形如：{"operation":">","threshold":"20"}
     * @param keyhash2   联动设备2（被动联动设备-执行设备，可以和触发设备keyhash相同）
     * @param attrName2  联动设备2的属性名
     * @param attrValue2 联动设备2下发的属性值
     * @param timeLimit  联动时间限制，在该时段内才有效。若为空，则表示全时段有效。
     *                   json格式数据： type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。
     *                   形如：{"type":"2","time":"12345-23456","week":"127"}
     * @param remark     备注
     * @param sceneId    加入指定的场景，
     * @param listener   callback(linkageId,retcode,errDescription)
     */
    void addDevLinkage(String keyhash, String attrName, String condition, String keyhash2, String attrName2, String attrValue2, String timeLimit, String remark, String sceneId, ZYListener.getStringInfo listener);

    /**
     * 修改一条设备联动
     *
     * @param linkageId  devLinkage id
     * @param keyhash    联动设备1（主动联动设备，触发设备）
     * @param attrName   联动设备1的属性名
     * @param condition  设备联动条件，json格式，形如：{"operation":">","threshold":"20"}
     * @param keyhash2   联动设备2（被动联动设备-执行设备，可以和keyhash相同）
     * @param attrName2  联动设备2的属性名
     * @param attrValue2 联动设备2下发的属性值
     * @param timeLimit  联动时间限制，在该时段内才有效。若为空，则表示全时段有效。
     *                   json格式数据： type：操控类型，0表示全时访问，无需time和week；1表示时段访问，无需week；2表示定期访问。time表示操控时间，如果是时段访问，内容为起始-结束时间戳（单位：秒），中间用-分割；如果是定期访问，内容为当天时间的起始秒-结束秒，中间用-分割。week表示星期，1-7分别表示周一到周日，如：137表示周一周三周日。
     *                   形如：{"type":"2","time":"12345-23456","week":"127"}
     * @param remark     备注
     * @param sceneId    加入指定的场景，
     * @param listener   callback
     */
    void modifyDevLinkage(String linkageId, String keyhash, String attrName, String condition, String keyhash2, String attrName2, String attrValue2, String timeLimit, String remark, String sceneId, ZYListener listener);

    /**
     * 删除一条设备联动
     *
     * @param linkageId dev linkage id
     * @param listener  callback
     */
    void deleteDevLinkage(String linkageId, ZYListener listener);

    /**
     * 用户反馈
     *
     * @param content  反馈内容
     * @param contact  联系方式
     * @param listener callback
     */
    void userFeedback(String content, String contact, ZYListener listener);


    /**
     * 获取属性操作对应内容
     *
     * @param devTypeId 设备类型Id
     * @param listener  callback list:DevAttrOperation
     */
    void getDevAttrOperation(String devTypeId, ZYListener.getAttrOperationList listener);

    /**
     * 获取绑定公众号的URL,使用微信扫描二维码内容为此URL的码可将筑云用户绑定公众号，然后可以接收到微信推送
     *
     * @param listener callback(wechatURLStr,retcode,errDescription)
     */
    void getWechatPublicQRCode(ZYListener.getStringInfo listener);

    /**
     * 根据语言获取所有消息类型
     * @param language：指定返回的语言内容，形如“en”
     * @param listener  callback(msgTypeList,retcode ,errDescription)
     */
    void getMessageTypeList(String language, ZYListener.getMsgTypeList listener);

   /** 获取消息列表-根据语言和设备类型获取
    * @param timestamp 截止时间戳（单位：毫秒），在这个时间之前的消息不获取；如果要获取所有消息，timestamp设为0；
    * @param devTypeId：指定的设备类型对应的消息，有多个设备类型时需要使用英文分号将设备类型分隔开，形如“1;2;3”；
    * @param language：指定返回的语言内容，形如“en”
     * @param listener callback(msgList,deleteMsgList,retcode ,errDescription)
     */
     void getMessageListForLanguage(long timestamp,String devTypeId,String language,ZYListener.getMsgList listener) ;
 
    /***
     * 获取服务器的DNS信息
     * 注：1、调用此接口前请先调用SDK接口setDNSKey设置DNSKey之后才可以成功获取APP对应的服务器DNS信息
           2、DNSKey是由筑云分配给APP开发者的，请提前申请
     * @param listener callback(httpDNSInfoList,retcode ,errDescription)
     */
   void getHttpDNSInfo(ZYListener.getHttpDNSInfoList listener);

    /**
     * 修改IOT Client的一些设置
     *
     * @param servers             IOT服务器IP或域名
     * @param clientStateListener IOT Client 状态变化监听
     * @param hexTypeSize         语音文件时单片分片的最大数据长度
     */
    public void setIOTClient(String servers, ZYIOTClientStateListener clientStateListener, int hexTypeSize);

    /**
     * 设置接收或发送语音文件分片的数据内容长度
     *
     * @param hexTypeSize max Frame length
     */
    public void setIOTHexTypeSize(int hexTypeSize);

    /**
     * 获取接收或发送语音文件分片的数据内容长度 max Frame length
     */
    public int getIOTHexTypeSize();

    /**
     * IOT服务器
     *
     * @param servers 设置IOT服务器IP或域名（若有多个，用英文符号分号隔开）
     */
    public void setIOTServer(String servers);

    /**
     * 设置监听IOTClient的状态监听
     *
     * @param clientStateListener IOT client状态变化中监听代理
     */
    public void setIOTClientStateListener(ZYIOTClientStateListener clientStateListener);

    /**
     * 修改IOT Client状态state:1(start or resume); 2(pause); -1(stop).
     * 注：不需要与设备进行设备通信时，pause或stop可以降低通信损耗。
     * 发送event时状态需要是已经start才可正常通信。
     *
     * @param state change iot client state
     */
    public void toASyncStartOrStopIOTClient(int state);

    /**
     * 增加代理监听event消息的发送和接收情况
     *
     * @param eventResponseListener 代理监听event消息情况
     */
    public void addZYEventResponseListener(ZYEventResponseListener eventResponseListener);

    /**
     * 移除指定监听
     *
     * @param eventResponseListener 代理监听event消息情况
     */
    public void removeZYEventResponseListener(ZYEventResponseListener eventResponseListener);

    /**
     * 增加代理监听IOT Client的在线和异常离线的状态变化
     *
     * @param onlineListener IOTOnlineListener
     */
    public void addZYClientOnlineListener(Online.IOTOnlineListener onlineListener);

    /**
     * 移除指定IOTOnlineListener代理
     *
     * @param onlineListener IOTOnlineListener
     */
    public void removeZYClientOnlineListener(Online.IOTOnlineListener onlineListener);

    /**
     * 获取本机的keyhash
     *
     * @return app phone keyhash
     */
    public String getPhoneKeyhash();

    /**
     * 获取IOT Client的状态。-1:stop, 1:start, 2:pause ,3:resume。
     */
    public int getIOTClientState();


    /**
     * APP母设备发送int值的event（如APP直接控制设备时）
     *
     * @param eventId       指定的消息ID
     * @param attrName      属性名
     * @param valueInt      int的属性值
     * @param targetKeyhash 发送event到指定设备
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventIntFromApp(int eventId, String attrName, int valueInt, String targetKeyhash);


    /**
     * APP母设备发送string值的event （如APP直接控制设备时）
     *
     * @param eventId       指定的消息ID
     * @param attrName      属性名
     * @param valueStr      string的属性值
     * @param targetKeyhash 发送event到指定设备
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventStrFromApp(int eventId, String attrName, String valueStr, String targetKeyhash);


    /**
     * APP母设备发送（NSData）hex值的event——如语音文件 （如APP直接控制设备时）
     *
     * @param eventId       指定的消息ID
     * @param attrName      属性名
     * @param valueHexBytes 发送NSData的属性值(如语音文件)
     * @param targetKeyhash 发送event到指定设备
     * @return 返回含eventId数值则成功，其余描述失败
     */
    public String sendEventHexFromApp(int eventId, String attrName, byte[] valueHexBytes, String targetKeyhash);


    /**
     * childDev发送int值的event（如子设备直接控制其它设备时）
     *
     * @param eventId         指定的消息ID
     * @param attrName        属性名
     * @param valueInt        int的属性值
     * @param targetKeyhash   发送event到指定设备
     * @param childDevKeyhash 子设备ID
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventIntFromChildDev(int eventId, String attrName, int valueInt, String targetKeyhash, String childDevKeyhash);


    /**
     * childDev发送string值的event（如子设备直接控制其它设备时）
     *
     * @param eventId         指定的消息ID
     * @param attrName        属性名
     * @param valueStr        string的属性值
     * @param targetKeyhash   发送event到指定设备
     * @param childDevKeyhash 子设备ID
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventStrFromChildDev(int eventId, String attrName, String valueStr, String targetKeyhash, String childDevKeyhash);

    /**
     * childDev发送（NSData）hex值的event-语音文件 (如子设备直接控制其它设备时）
     *
     * @param eventId         指定的消息ID
     * @param attrName        属性名
     * @param valueHexBytes   NSData的属性值
     * @param targetKeyhash   发送event到指定设备
     * @param childDevKeyhash 子设备ID
     * @return 返回含eventId数值则成功，其余描述失败
     */
    public String sendEventHexFromChildDev(int eventId, String attrName, byte[] valueHexBytes, String targetKeyhash, String childDevKeyhash);

    /**
     * APP母设备发送event（如APP直接控制设备时）
     *
     * @param eventId       指定的消息ID
     * @param attrType      属性值类型：1(string) ,2(int), 3(string+int), 4(hex). 指定了属性值类型，则对应的属性值字段才有效（如type=1，valueStr有效）
     * @param attrName      属性名
     * @param valueStr      string类型的属性值
     * @param valueInt      int类型的属性值
     * @param valueHexBytes NSData类型的属性值
     * @param targetKeyhash 指定的设备
     * @return 返回含eventId数值则成功，其余描述失败
     */
    public String sendEventFromApp(int eventId, int attrType, String attrName, String valueStr, int valueInt, byte[] valueHexBytes, String targetKeyhash);

    /**
     * APP直连子设备发送event（如APP直接控制设备时），比如蓝牙设备会先连接手机，然后调用子设备登录成功后，再使用本接口将蓝牙设备当前状态通过event上传到服务器保存。
     *
     * @param eventId         指定的消息ID
     * @param attrType        属性值类型：1(string) ,2(int), 3(string+int), 4(hex). 指定了属性值类型，则对应的属性值字段才有效（如type=1，valueStr有效）
     * @param attrName        属性名
     * @param valueStr        string类型的属性值
     * @param valueInt        int类型的属性值
     * @param valueHexBytes   NSData类型的属性值
     * @param targetKeyhash   指定的设备
     * @param childDevKeyhash 子设备ID
     * @return 返回含eventId数值则成功，其余描述失败
     */
    public String sendEventFromChildDev(int eventId, int attrType, String attrName, String valueStr, int valueInt, byte[] valueHexBytes, String targetKeyhash, String childDevKeyhash);

    /**
     * APP直连子设备登录
     *
     * @param childDevType    子设备的类型，指的是蓝牙设备等app直连设备类型，目前支持bluetooth（小写字母）
     * @param childDevKeyhash 连接app成功的子设备ID
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String childDevLogin(String childDevType, String childDevKeyhash);

    /**
     * APP直连子设备退出登录
     *
     * @param childDevType    子设备的类型，指的是蓝牙设备等app直连设备类型，目前支持bluetooth（小写字母）
     * @param childDevKeyhash 与app连接断开的子设备ID
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String childDevLogout(String childDevType, String childDevKeyhash);


    /**
     * 读取指定设备的指定属性值。
     * 注意：读取hex类型的属性时应该attrName=指定attrName，type=1，返回的是hex文件ID列表(形如objectId_timestamp,objectId_timestamp)。然后将文件ID列表中的objectId值作为attrName(此时type=4)依次发送event去获取文件内容。
     *
     * @param targetKeyhash 指定设备ID
     * @param attrName      指定属性名
     * @param attrType      属性值类型
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventToReadDevAttrFromAPP(int eventId, String targetKeyhash, String attrName, int attrType);

    /**
     * 读取指定APP直连子设备的指定属性值。
     * 注意：读取hex类型的属性时应该attrName=指定attrName，type=1，返回的是hex文件ID列表(形如objectId_timestamp,objectId_timestamp)。然后将文件ID列表中的objectId值作为attrName(此时type=4)依次发送event去获取文件内容。
     *
     * @param targetKeyhash   指定读取的设备ID
     * @param childDevKeyhash 再将得到的值发回给指定子设备
     * @param attrName        指定属性名
     * @param attrType        属性值类型
     * @return 返回eventId数值则成功，其余描述失败
     */
    public String sendEventToReadDevAttrFromChildDev(int eventId, String targetKeyhash, String childDevKeyhash, String attrName, int attrType);



}
