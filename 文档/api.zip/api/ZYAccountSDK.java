package com.zyiot.sdk;

import android.content.Context;

import com.zyiot.sdk.entity.AuthorityEntity;
import com.zyiot.sdk.dao.ZYListener;
import com.zyiot.sdk.entity.ChargeInfo;
import com.zyiot.sdk.entity.ZYUser;

 public class ZYAccountSDK extends ZYBaseSDK{
    
     /**
     * 获取接口实例
     *
     * @return ZYAccountSDK
     */
    public static ZYAccountSDK getZYAccountSDKInstance(Context context);

    /** 用户使用手机或邮箱登录
     * @param account   已注册筑云的手机或邮箱
     * @param password  筑云用户密码
     * @param phonePush 手机推送，android_0表示百度云推送，android_1表示gcm推送。
     * @param channelId 推送通道id
     * @param language  语言(中国zh，美国en)
     * @param listener  callback(ZYUserToken,retcode ,errText)
     */
    void login(String account, String password, ZYUser.PhonePushEnum phonePush, String channelId, String language, ZYListener.getUserToken listener) ;
    void login(int tenantId,String account, String password, ZYUser.PhonePushEnum phonePush, String channelId, String language, ZYListener.getUserToken listener) ;

        /***获取注册验证码
         * 注：1.邮箱验证码有效期一个小时，短信验证码有效期3分钟
               2.密码只是验证码发送时带回作用，实际密码以用户注册api为准。
         * @param account 手机号或邮箱号
         * @param password 注册密码，会随验证码一起发送
         * @param listener callback(retcode,errDescription)
         */
    void getRegistVerify( String account, String password, ZYListener listener);

    /***
     *  注册用户
     * @param account 手机号或邮箱号
     * @param password 用户密码
     * @param verifyCode 收到的验证码
     * 以下三个是可选参数：
     * @param phonePush 手机接收推送的方式
     * @param channelId 推送通道id
     * @param language 指定接收推送内容的语言
     * @param listener  callback(userToken,retcode,errDescription)
     */
    void regist( String account, String password, String verifyCode, ZYUser.PhonePushEnum phonePush, String channelId,  String language,ZYListener.getUserToken listener) ;


    /***
     * 设置用户信息
     以下参数非必须全有，需设定的值有即可，其他值置空。
     *@param nickname：昵称
     * @param msgSwitch：消息推送开关
     * @param pushSwitch：推送总开关
     * @param wechatSwitch：微信推送总开关
     * @param phonePush：手机推送
     * @param channelId：推送通道id
     * @param noDisturbTime：消息免打扰时间（以秒为单位，中间用‘-’隔开，如：12345-34567；如果结束时间小于起始时间，说明是第二天）
     * @param headProtrait：头像路径
     * @param ring：个性铃声
     * @param language：语言（ZH中文，EN英文）
     * @param fontSize：字体大小
     * @param personalInfo：个人信息
     * @param listener  callback(retcode,errDescription)
     */
    void setUserInfo(  String nickname, String msgSwitch, String pushSwitch,  String wechatSwitch, ZYUser.PhonePushEnum phonePush, String channelId, String noDisturbTime, String headProtrait, String ring, String language, int fontSize, String personalInfo, ZYListener listener);

    /***
     *获取用户信息
     * @param listener callback(userInfo,retcode,errDescription)
     */
    void getUserInfo( ZYListener.getUserInfo listener)  ;

   /***
    * 用户修改密码
    * @param  oldPassword：原密码
    * @param newPassword：新密码
    * @param listener callback(retcode,errDescription)
     */
    void modifyPassword( String oldPassword, String newPassword,  ZYListener listener);

    /***
     * 忘记密码：获取验证码
     * 注：1.如果有绑定邮箱，优先发送验证码到邮箱
          2.用于忘记密码，设置新密码。
     * @param account：手机号或邮箱
     * @param password：新设置的密码
     * @param listener callback(isPhone,smsRemain,account,retcode,errDescription)
     */
     void getForgetPwdVerify( String account, String password, ZYListener.getVerifyCodeResult listener)  ;

     /***
      * 忘记密码：设置新密码
      * @param account：手机号或邮箱
      * @param password：新设置的密码
      * @param verifyCode：验证码
     * @param listener callback(retcode,errDescription)
     */
      void forgetPwdAndSetNew( String account, String password, String verifyCode, ZYListener listener) ;


    /***
     * 修改绑定账号（修改手机或邮箱）-获取验证码
     * 注：用于修改或绑定手机号/邮箱号。
     * @param account：要修改/绑定的手机号或邮箱号
     * @param password：用户密码
     * @param listener callback(isPhone,smsRemain,retcode,errDescription)
     */
    void getModifyAccountVerify( String account, String password, ZYListener.getModifyAccountVerifyResult listener);

    /***
     * 修改（或绑定）手机号或邮箱号
     * @param account：要修改的手机号或邮箱号
     * @param password：用户密码
     * @param verifyCode：验证码
     * @param listener callback(retcode,errDescription)
     */
    void modifyAccount( String account, String password, String verifyCode, ZYListener listener);




    /**
     * 解除微信公众号绑定（解除后无法收到微信通知）
     * @param listener callback(retcode,errDescription)
     */
    void wechatRemovePublic( ZYListener listener);

   

    /**
     * 注销用户
     * 注：注销后用户无法登录筑云平台，需要重新注册
     * @param password 密码
     * @param listener callback(retcode,errDescription)
     */
    void deleteUser( String password, ZYListener listener);




    /**一级用户授权给二级用户
     注：设备未购买任何套餐，设备的二级用户最高9个，购买任意设备套餐后，最高99个。
     * @param keyhash：指定设备keyhash
     * @param account：被授权的二级用户的账号(已注册的手机或邮箱)
     * @param authority：用户控制权限，json数据。格式详见com.zyiot.sdk.entity.AuthorityEntity.java与AuthorityEntity1.java、AuthorityEntity2.java文件
     * @param remark：备注
     * @param listener callback(authUser,retcode,errDescription)
     */ 
    void authorizeUser(String keyhash, String account, AuthorityEntity authority, String remark, ZYListener.authToUser listener);


    /**
     * 一级用户修改二级用户权限
     * @param keyhash：指定设备keyhash
     * @param authUserId：被授权的二级用户userId，这里不用account
     * @param authority：用户控制权限，json数据。格式详见com.zyiot.sdk.entity.AuthorityEntity.java与AuthorityEntity1.java、AuthorityEntity2.java文件
     * @param remark：备注
     * @param listener callback(retcode,errDescription)
    */ 
    void modifyAuthUser( String keyhash, String authUserId, AuthorityEntity authority, String remark, ZYListener listener);


    /***
     * 一级用户解授权二级用户 （解授权后，二级用户失去对设备的权限）
     * @param keyhash：指定设备keyhash
     * @param authUserId：被授权的二级用户userId，这里不用account
     * @param listener callback(retcode,errDescription)
     */
    void unAuthorizeUser( String keyhash, String authUserId, ZYListener listener);

    /**
     * 获取设备所属的用户列表（包括二级用户，临时用户）
     * @param keyhash 指定设备
     * @param listener callback(authUserList,tempUserList,retcode,errDescription)
     */
    void getUserList( String keyhash, ZYListener.getUserList listener);

    /***
     * 转移设备管理员权限给指定用户
     * 注：1.管理员才可以转移设备，转移设备后该用户失去管理员权限，设备下的所有二级用户、临时用户均被删除，设备新管理员是指定的用户。
     *@param loginPwd 转移设备管理员权限需要用户登录密码
     * @param keyhash 设备
     * @param account 转移给指定用户（为已注册的手机或邮箱）
     * @param listener callback(retcode,errDescription)
     */
    void moveDevToUser(String loginPwd, String keyhash, String account,ZYListener listener ) ;


    /**
     * 获取所有的设备套餐信息
     * @param listener callback(chargeInfos,retcode,errDescription)
     */
    void getDevChargeInfos( ZYListener.getChargeInfoList listener);


     /**
     * 获取设备已购套餐信息
     * @param keyhash 指定设备
     * @param listener callback(purchasedChargeInfoMap,retcode,errDescription)
     */
    void getDevChargePurchasedInfoMap( String keyhash, ZYListener.getPurchasedChargeInfoMap listener);

    /***
     * 获取设备套餐的价格
     * @param chargeId 指定套餐Id
     * @param listener callback(chargeInfo,retcode,errDescription)
     */
    void getDevChargePayPrice( String chargeId, ZYListener.getPriceForChargeInfo listener);


    /**
     * 提交购买设备套餐结果（下单、支付的流程在商城类APP及其后台自己实现，购买成功后再调用本接口，本SDK不涉及金钱）
     * @param keyhash 指定设备
     * @param chargeId 指定套餐Id
     * @param listener callback(retcode,errDescription)
     */
    void buyDevChargeNo( String keyhash, String chargeId, ZYListener listener);


    /**
     * 删除已购买的设备套餐
     * 注：如果用户购买设备录套餐后想要换套餐，要先删除套餐，再购买新套餐
     * @param keyhash 指定设备
     * @param chargeMark 套餐类型标志，1历史记录套餐，2操控套餐
     * @param listener callback(retcode,errDescription)
     */
    void deleteDevCharge(String keyhash, ChargeInfo.ChargeTypeEnum chargeMark, ZYListener listener);


    /**
     * 为设备设置月推邮箱
     * 注：1、月推邮箱是需要购买了设备套餐才可以设置；2、只有设备的管理员可以设置月推邮箱；3、筑云后台于每月1号0点0分发出月推送，月推邮箱接收到的内容是设备上个月产生的历史记录（包括：设备异常状态、设备操控记录、设备绑定分享记录）
     * 月推邮箱账号默认包含设备管理员的邮箱。
     * @param keyhash 指定设备
     * @param email 月推邮箱，可以设置两个，邮箱之间用英文符号分号‘;’分隔开，形如“cxm@qq.com;cxm2@qq.com”
     * @param listener callback(retcode,errDescription)
     */
    void setDevPushEmail( String keyhash, String email, ZYListener listener);



    /**
     * 获取短信套餐信息
     * 注：用户可以在不登录的情况下充值。
     * @param listener callback(SMSChargeInfos,retcode,errDescription)
     */
    void getSMSChargeInfos( ZYListener.getChargeInfoSMSList listener);

    /**
     * 获取短信套餐的价格
     * @param chargeId 指定套餐Id
     * @param listener callback(chargeInfo,retcode,errDescription)
     */
    void getSMSChargePayPrice( String chargeId, ZYListener.getPriceForChargeInfoSMS listener);

    /***
     *  提交购买短信套餐结果（下单、支付的流程在商城类APP及其后台自己实现，购买成功后再调用本接口，本SDK不涉及金钱）
     * @param phoneNum 手机号（已注册的手机号）
     * @param chargeId 指定套餐Id 
     * @param listener callback(retcode,errDescription)
     */
    void buySMSChargeNo(String phoneNum,String chargeId,  ZYListener listener);


}
